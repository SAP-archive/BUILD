/*!
 * SAP APF Analysis Path Framework
 * 
 * (c) Copyright 2012-2014 SAP AG. All rights reserved
 */
jQuery.sap.declare('sap.apf.modeler.ui.utils.constants');
sap.apf.modeler.ui.utils.CONSTANTS = {
	configurationObjectTypes : {
		CONFIGURATION : "configuration",
		FACETFILTER : "facetFilter",
		CATEGORY : "category",
		STEP : "step",
		REPRESENTATION : "representation",
		NAVIGATIONTARGET : "navigationTarget",
		ISNEWCONFIG : "apf1972-"
	}
};