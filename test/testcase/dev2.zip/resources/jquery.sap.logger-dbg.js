/*!
 * ${copyright}
 */

/*
 * Abandoned, empty module (since 1.1.2). Functionality has been integrated into module 'jquery.sap.global'.
 */
jQuery.sap.declare("jquery.sap.logger", false);
