/*!
 * SAP APF Analysis Path Framework
 *
 * (c) Copyright 2012-2014 SAP SE. All rights reserved
 */
/*global sap, jQuery*/

jQuery.sap.declare("sap.apf.modeler.core.textPool");
jQuery.sap.require("sap.apf.utils.hashtable");
jQuery.sap.require("sap.apf.core.utils.filter");
jQuery.sap.require("sap.ui.core.format.DateFormat");
(function() {
	'use strict';

	/**
	 * @private 
	 * @description holds all texts of an application, that are used in the analytical configurations
	 * @class TextPool
	 * @param {object} inject Injection of required APF objects
	 * @param {object} inject.instance  Injection of required instances
	 * @param {object} inject.instance.messageHandler Injection of messageHandler instance
	 * @param {object} inject.instance.persistenceProxy Injection of persistenceProxy instance
	 * @param {object} inject.constructor  Injection of required constructors
	 * @param {object} inject.constructor.hashtable  Injection of hashtable constructor 
	 * @param {string} applicationId is the guid of the application
	 * @param {object[]} existingTexts that have been fetched from DB
	 */
	sap.apf.modeler.core.TextPool = function(inject, applicationId, existingTexts) {

		var messageHandler = inject.instance.messageHandler;
		var persistenceProxy = inject.instance.persistenceProxy;

		var Hashtable = inject.constructor.hashtable;

		var hashTableForTexts = new Hashtable(messageHandler);
		var keyMappingTable = new Hashtable(messageHandler);
		var guidMappingTable = new Hashtable(messageHandler);
		var bFormatInformationIsMissing;
		var keyCounter = 0;
		var defaultInitialTextElement = {
				TextElement : sap.apf.core.constants.textKeyForInitialText,
				Language : sap.apf.core.constants.developmentLanguage,
				TextElementType : "XFLD",
				TextElementDescription : "",
				MaximumLength : 10,
				Application : applicationId,
				TranslationHint : ""
		};

		function findExistingTextElement(textElementDescription, format) {
			var keys = hashTableForTexts.getKeys();
			var i, len = keys.length;
			var maximumLength = format.MaximumLength || 10;
			var translationHint = format.TranslationHint || "";
			var textElement;
			
			for (i = 0; i < len; i++) {
				textElement = hashTableForTexts.getItem(keys[i]);
				if ((textElement.TextElementDescription === textElementDescription) &&
					(textElement.MaximumLength === maximumLength) &&
					(textElement.TranslationHint === translationHint)) {
					return keys[i];
				}
			}
			return undefined;
		}
		
		function renderHeaderOfTextPropertyFile() {

			var translationUuid = applicationId.toLowerCase();
			var checkValidFormatRegex = /^[0-9a-f]+$/;
			var isValid = checkValidFormatRegex.test(translationUuid);

			if (!isValid || applicationId.length !== 32) {
				messageHandler.putMessage(messageHandler.createMessageObject({
					code : "11009",
					aParameters : [ applicationId ]
				}));

				translationUuid = "<please enter valid translation uuid, if you want to upload into a SAP translation system>";
			} else {
				translationUuid = translationUuid.substring(0, 8) + '-' + translationUuid.substring(8, 12) + '-' + translationUuid.substring(12, 16) + '-' + translationUuid.substring(16, 20) + '-' + translationUuid.substring(20);
			}

			return "#FIORI: insert Fiori-Id\n" + "# __ldi.translation.uuid=" + translationUuid + "\n" + "#ApfApplicationId=" + applicationId + "\n\n";
		}

		/*
		 * #Kind,length:hint
		 * TextElement=TextElementDescription
		 */
		function renderEntryOfTextPropertyFile(textData) {
			var dateString, oDate;
			
			if (!bFormatInformationIsMissing && (!textData.TextElementType || !textData.MaximumLength)) {
				bFormatInformationIsMissing = true;
				messageHandler.putMessage(messageHandler.createMessageObject({
					code : "11008",
					aParameters : [ textData.TextElement ]
				}));

			}
			var entry = "#" + (textData.TextElementType || "<Add text type>") + "," + ( textData.MaximumLength || "<Add maximum length>");
		
			if (textData.TranslationHint && textData.TranslationHint !== "") {
				entry = entry + ':' + textData.TranslationHint;
			}
			entry = entry + "\n" + textData.TextElement + "=" + textData.TextElementDescription + "\n";
			
			var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({pattern: "yyyy/MM/dd HH:mm:ss"});
			
			if (textData.LastChangeUTCDateTime && textData.LastChangeUTCDateTime !== "") {
				dateString = textData.LastChangeUTCDateTime.replace(/\/Date\(/,'').replace(/\)\//, '');
				oDate = new Date(parseInt(dateString,10));
				
			} else {
				 oDate = new Date();
			}
			entry = entry + "# LastChangeDate=" +  oDateFormat.format(oDate) + '\n\n';
			
			return entry;
		}
		
		/**
		 * @description delete texts from text pool
		 * @param {string[]} textElementKeys array with TextElements (keys) to be added
		 * @param {function} callback is called, when save is finished. Signature is fn( sap.apf.core.MessageObject )
		 */	
		this.removeTexts = function(textElementKeys, callback) {
			
			var batchRequests = [];
			var i, len;
			
			function callbackRemove(messageObject) {
				var j;
				if (!messageObject) {
					for (j = 0; j < len; j++) {
						hashTableForTexts.removeItem(textElementKeys[j]);
					}
				}
				callback(messageObject);
				
			}
					
			len = textElementKeys.length;	
			if (len === 0) {
				callback(undefined);
				return;
			}
		
			for (i = 0; i < len; i++) {
				if (textElementKeys[i] === sap.apf.core.constants.textKeyForInitialText) {
					continue;
				}
				batchRequests.push( { method : "DELETE", entitySetName : "texts", 
					inputParameters : [ {  name : 'TextElement', value : textElementKeys[i] }, { name : 'Language', value: sap.apf.core.constants.developmentLanguage } ] });
			}
			
			persistenceProxy.doChangeOperationsInBatch( batchRequests, callbackRemove);
		};
		
	    this.isInitialTextKey = function(textKey) {
	        	return (textKey === sap.apf.core.constants.textKeyForInitialText);
	    };
	       
		/**
		 * @description add texts to the text pool and save them
		 * @param {object[]} TextElements array with TextElements to be added
		 * @param {function} callback is called, when save is finished. Signature is fn( sap.apf.core.MessageObject )
		 */		
		this.addTextsAndSave = function(textElements, callback) {
			function areEqualTextElements(text1, text2){
		
				return (text1.TextElement === text2.TextElement && text1.TextElementDescription === text2.TextElementDescription &&
						text1.MaximumLength === text2.MaximumLength && text1.Language === text2.Language && text1.TranslationHint === text2.TranslationHint);
			}
			
		 
			var i;
			var len = textElements.length;
			var existingTextElement;
			var textElementsForUpdate = [];
			var textElementsForCreate = [];
			var changeRequests = [];
			var inputParameters;
			for (i = 0; i < len; i++) {
				if (textElements[i] === sap.apf.core.constants.textKeyForInitialText) {
					continue;
				}
				existingTextElement = hashTableForTexts.getItem(textElements[i].TextElement);
				if (existingTextElement) {
					if (!areEqualTextElements(existingTextElement,textElements[i])) {
						textElementsForUpdate.push(textElements[i]);
						hashTableForTexts.setItem(textElements[i].TextElement, textElements[i]);
					}
				} else {
					textElementsForCreate.push(textElements[i]);
					hashTableForTexts.setItem(textElements[i].TextElement, textElements[i]);
				}
			}
			len = textElementsForUpdate.length;
			for (i = 0; i < len; i++) {
				inputParameters = [ { name : 'TextElement', value : textElementsForUpdate[i].TextElement },
				                    { name : 'Language', value : textElementsForUpdate[i].Language }];
				
				textElementsForUpdate[i].MaximumLength = parseInt(textElementsForUpdate[i].MaximumLength, 10);
				changeRequests.push( { method : "PUT", entitySetName : "texts", data : textElementsForUpdate[i], inputParameters: inputParameters });
			}
			len = textElementsForCreate.length;
			for (i = 0; i < len; i++) {
				textElementsForCreate[i].MaximumLength = parseInt(textElementsForCreate[i].MaximumLength, 10);
				changeRequests.push( { method : "POST", entitySetName : "texts", data : textElementsForCreate[i] });
			}
			
			if (changeRequests.length > 0) {
				persistenceProxy.doChangeOperationsInBatch(changeRequests, callback);
			} else {
				callback(undefined);
			}
			
		};
		
		/**
		 * @description creates a .property file, that suffices the SAP translation format
		 * @returns {string} textPropertyFile
		 */
		this.exportTexts = function() {
			var textPropertyFile = renderHeaderOfTextPropertyFile();
			var i, length;
			
			bFormatInformationIsMissing = false;
			
			var keys = hashTableForTexts.getKeys();

			keys.sort(function(a, b) {
				var valueA = hashTableForTexts.getItem(a);
				var valueB = hashTableForTexts.getItem(b);

				if (valueA.LastChangeUTCDateTime < valueB.LastChangeUTCDateTime) {
					return -1;
				}
				if (valueA.LastChangeUTCDateTime > valueB.LastChangeUTCDateTime) {
					return 1;
				}

				return 0;
			});

			length = keys.length;
			for(i = 0; i < length; i++) {

				textPropertyFile = textPropertyFile + renderEntryOfTextPropertyFile(hashTableForTexts.getItem(keys[i]));
			}
			return textPropertyFile;
		};

		/**
		 * gets the text for a given id
		 * @param {string} id either temporary or persistent id of the key.
		 * @returns {object} text
		 */
		this.get = function(id) {
			var databaseKey, notExistingTextElement;
			
			if (id === sap.apf.core.constants.textKeyForInitialText) {
				return defaultInitialTextElement;
			}
			if (hashTableForTexts.hasItem(id)) {
				return hashTableForTexts.getItem(id);
			}
			if (keyMappingTable.hasItem(id)) {
				databaseKey = keyMappingTable.getItem(id);
				if (databaseKey.TextElementDescription) {
					return databaseKey;
				}
				return hashTableForTexts.getItem(databaseKey);
			}
			notExistingTextElement = jQuery.extend({}, true, defaultInitialTextElement);
			notExistingTextElement.TextElement = id;
			notExistingTextElement.TextElementDescription = id;
			return notExistingTextElement; //finally no text was found
		};

		/**
		 * gets the database key (guid) of a text for a given id
		 * @param {string} id either temporary or persistent id (guid) of the key.
		 * @returns {string} textElement
		 */
		this.getPersistentKey = function(id) {

			return id;
		};
		/**
		 * @param {string} textElementDescription : "TITLE",
		 * @param {Object} format
		 * @param {string} format.TextElementType  example title TITLE",
		 * @param {number} format.MaximumLength
		 * @param {string} format.TranslationHint
		 * @returns {string} key
		 */
		this.setText = function(textElementDescription, format) {
			var artificalKey;
			var textKey;
			var updateTextAndMappingTable = function(textData, metadata, messageObject) {

				if (messageObject) {
					messageHandler.putMessage(messageObject);
				}

				if (textData) {
					hashTableForTexts.setItem(textData.TextElement, textData);
					textKey = textData.TextElement;
					//replace the temporary data with key!
					//keyMappingTable.setItem(artificalKey, textData.TextElement);
					//guidMappingTable.setItem(textData.TextElement, artificalKey);
				}
			};
			var data = {
				TextElement : "", //key should be filled automatically
				Language : sap.apf.core.constants.developmentLanguage,
				TextElementType : format.TextElementType,
				TextElementDescription : textElementDescription,
				MaximumLength : format.MaximumLength || 10,
				Application : applicationId,
				TranslationHint : format.TranslationHint || ""
			};

			if (!textElementDescription) {
				return sap.apf.core.constants.textKeyForInitialText;
			}
			textKey = findExistingTextElement(textElementDescription, format);
			if (textKey) {
				return textKey;
			}
			keyCounter++;
			artificalKey = "textKey" + keyCounter;

			// temporary set the data. this will be replaced, when creation on server succeeded;
			//this lives as long, as server request is not returned
			//keyMappingTable.setItem(artificalKey, 'UNMAPPED');
			persistenceProxy.create('texts', data, updateTextAndMappingTable, false);
			//return artificalKey;
			return textKey;
		};
		/**
		 * returns an array with keys of all texts of given
		 * @param {string} textElementType - optional
		 * @returns {string[]} array with text keys
		 */
		this.getTextKeys = function(textElementType) {
			var keys = hashTableForTexts.getKeys();
			var i, text, len = keys.length;
			var textKeys = [];

			for(i = 0; i < len; i++) {
				text = hashTableForTexts.getItem(keys[i]);

				if (textElementType && text.TextElementType !== textElementType) {
					continue;
				}	
				
				if (guidMappingTable.hasItem(keys[i])) {
					textKeys.push(guidMappingTable.getItem(keys[i]));
				} else {
					textKeys.push(keys[i]);
				}

			}
			return textKeys;
		};

		/**
		 * return all texts with properties TextElement and TextElementDescription for given TextElementType and MaximumLength
		 * @param {string} textElementType
		 * @param {number} maximumLength
		 * @returns {object[]} textElements
		 */
		this.getTextsByTypeAndLength = function(textElementType, maximumLength) {
			var keys = hashTableForTexts.getKeys();
			var i, text, len = keys.length;
			var textElements = [];

			for(i = 0; i < len; i++) {
				text = hashTableForTexts.getItem(keys[i]);

				if (text.TextElementType === textElementType && text.MaximumLength === maximumLength) {
					if (guidMappingTable.hasItem(keys[i])) {
						textElements.push({
							TextElement : guidMappingTable.getItem(keys[i]),
							TextElementDescription : text.TextElementDescription
						});
					} else {
						textElements.push({
							TextElement : keys[i],
							TextElementDescription : text.TextElementDescription
						});
					}

				}
			}
			return textElements;
		};

		function initialize() {
			var i, len;

			len = existingTexts.length;
			for(i = 0; i < len; i++) {
				hashTableForTexts.setItem(existingTexts[i].TextElement, existingTexts[i]);
			}
		}

		initialize();
	};

}());
