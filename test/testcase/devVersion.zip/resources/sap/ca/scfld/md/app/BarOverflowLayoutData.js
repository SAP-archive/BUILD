/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
sap.ui.define(['sap/ui/core/LayoutData'],function(l){"use strict";var B=l.extend("sap.ca.scfld.md.app.BarOverflowLayoutData",{metadata:{properties:{moveToOverflow:{type:"boolean",defaultValue:true},stayInOverflow:{type:"boolean",defaultValue:false},overflowButton:{type:"boolean",defaultValue:false}}}});return B;},true);
