/*!
 * ${copyright}
 */
jQuery.sap.declare("jquery.sap.logger",false);
