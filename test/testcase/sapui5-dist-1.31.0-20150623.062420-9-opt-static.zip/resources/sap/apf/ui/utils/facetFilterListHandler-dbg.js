/*!
 * SAP APF Analysis Path Framework
 *
 * (c) Copyright 2012-2014 SAP AG. All rights reserved
 */
jQuery.sap.declare('sap.apf.ui.utils.facetFilterListHandler');
jQuery.sap.require('sap.apf.ui.representations.utils.formatter');
jQuery.sap.require('sap.apf.ui.utils.promiseBasedCreateReadRequest');
/**
 * @private
 * @experimental The complete class interface is subject to ongoing work and not yet stable (as of Version 1.24.0).
 * @class Facet filter list handler
 * @description Handler for facet filter list controls
 * @param {sap.apf.core.instance} oCore Api
 * @param (sap.apf.utils.PathContextHandler} Path context handler instance.
 * @param {Array} facet filter configuration of the filter.
 * @name sap.apf.ui.utils.FacetFilterHandler
 * @returns {sap.apf.ui.utils.FacetFilterHandler}
 */
sap.apf.ui.utils.FacetFilterListHandler = function(oCoreApi, oUiApi, oPathContextHandler, oFacetFilterData) {
	"use strict";
	var oFilterTitle = oFacetFilterData.label;
	var sFilterProperty = oFacetFilterData.property;
	var sAlias = oFacetFilterData.alias;
	var sSelectProperty = sAlias || sFilterProperty;
	var sFrr = oFacetFilterData.filterResolutionRequest;
	var sVhr = oFacetFilterData.valueHelpRequest;
	var oMasterDataDeffered;
	var oSelectDataDeffered;
	var bTriedTextResolutionBefore = false; // To make sure that text resolution does not happen again on "open path scenario".
	var bHasServedBefore = false; // To make sure that the filter value is not saved as initial context during "open path scenario".
	var aSelectedFilterValues = [];
	var bEvaluationHasChanged = false;//To make sure text resolution happens again in case path saved with an old evaluation is opened
	/**
	 * @public
	 * @function
	 * @name sap.apf.ui.utils.FacetFilterListHandler#fetchValueHelpData
	 * @description Returns a promise which will be resolved with value help data when the request is successful
	 * It will be rejected with error object if the request does not succeed.
	 * The promise will get resolved with an empty array if value help request is not available.
	 * The promise will get resolved with an {Array} with elements of type {key: skey, text: sText}.
	 * @returns {object} jQuery Promise
	 * */
	this.fetchValueHelpData = function() {
		oMasterDataDeffered = new jQuery.Deferred();
		if (sVhr) {
			var oVhrPromise = new sap.apf.ui.utils.PromiseBasedCreateReadRequest(oCoreApi, sVhr);
			oVhrPromise.then(this._getFormattedData).then(this._resolveMasterDataPromiseWith, this._handleVhrError);
		} else {
			this._resolveMasterDataPromiseWith([]);
		}
		return oMasterDataDeffered.promise();
	};
	/**
	 * @public
	 * @function
	 * @name sap.apf.ui.utils.FacetFilterListHandler#fetchSelectedFilterData
	 * @description Returns a promise which will be resolved with selected filter data.
	 * The promise will get resolved with an empty array if filter is not available in path context.
	 * The promise will get resolved with an {Array} with elements of type {key: skey, text: sText}.
	 * It will be rejected with error object if the request does not succeed.
	 * @returns {object} jQuery Promise
	 * */
	this.fetchSelectedFilterData = function() {
		oSelectDataDeffered = new jQuery.Deferred();
		var bPropertyPresentInContext = oPathContextHandler.getAllIds().indexOf(sFilterProperty) !== -1;
		if (bPropertyPresentInContext) {
			var oFilter = oPathContextHandler.get(sFilterProperty);
			//check performed to see values coming from the path context handler are present in current evaluation
			var aSelectedKeys = oFilter.getInternalFilter().getFilterTerms().map(function(term) {
				return term.getValue();
			});
			aSelectedKeys.forEach(function(key) {
				var aMatchingDataRows = aSelectedFilterValues.filter(function(oDataRow) {
					return oDataRow.key === key;
				});
				if (!aMatchingDataRows.length && !sVhr) {
					bEvaluationHasChanged = true;
				}
			});
			var aOperators = oFilter.getInternalFilter().getFilterTerms().map(function(term) {
				return term.getOp();
			});
			var bHasRelationalOperators = aOperators.some(function(op) {
				return op !== "EQ";
			});
			if (bHasRelationalOperators || (!sVhr && !bTriedTextResolutionBefore) || bEvaluationHasChanged) {
				bTriedTextResolutionBefore = true;
				bEvaluationHasChanged = false;
				if (sFrr) {
					var oFrrPromise = new sap.apf.ui.utils.PromiseBasedCreateReadRequest(oCoreApi, sFrr, oFilter);
					oFrrPromise.then(this._resolveRelationalOperatorFromPCH, this._handleFrrError).then(this._getFormattedData).then(this._resolveSelectDataPromiseWith);
					return oSelectDataDeffered.promise();
				}
				if (bHasRelationalOperators) {
					this._handleFrrError();
					return oSelectDataDeffered.promise();
				}
			}
			var aData = oFilter.getInternalFilter().getFilterTerms().map(function(term) {
				return {
					key : term.getValue(),
					text : term.getValue()
				};
			});
			this._resolveSelectDataPromiseWith(aData);
		} else {
			this._resolveSelectDataPromiseWith([]);
		}
		return oSelectDataDeffered.promise();
	};
	this._resolveMasterDataPromiseWith = function(aValues, oError) {
		oMasterDataDeffered.resolveWith(this, [ aValues, oError ]);
	};
	this._resolveSelectDataPromiseWith = function(aValues, oError) {
		bHasServedBefore = true;
		aSelectedFilterValues = aValues;
		oSelectDataDeffered.resolveWith(this, [ aValues, oError ]);
	};
	this._getFormattedData = function(oArg) {
		var aData = oArg.aData;
		var oMetadata = oArg.oMetadata;
		var oFormatter = new sap.apf.ui.representations.utils.formatter({
			getEventCallback : oUiApi.getEventCallback.bind(oUiApi),
			getTextNotHtmlEncoded : oCoreApi.getTextNotHtmlEncoded
		}, oMetadata, aData);
		var sTextProperty = oMetadata.getPropertyMetadata(sSelectProperty).text;
		var aFormattedData = aData.map(function(oData) {
			var sFormattedKeyPropertyValue = oFormatter.getFormattedValue(sSelectProperty, oData[sSelectProperty]);
			var sTextValue;
			if (sTextProperty) {
				var sFormattedTextPropertyValue = oFormatter.getFormattedValue(sTextProperty, oData[sTextProperty]);
				sTextValue = sFormattedKeyPropertyValue + " - " + sFormattedTextPropertyValue;
			} else {
				sTextValue = sFormattedKeyPropertyValue;
			}
			return {
				key : oData[sSelectProperty],
				text : sTextValue
			};
		});
		return aFormattedData;
	};
	this._resolveRelationalOperatorFromPCH = function(oArg) {
		var aData = oArg.aData;
		var oMetadata = oArg.oMetadata;
		var oFilter = oCoreApi.createFilter();
		var oOrTerm = oFilter.getTopAnd().addOr();
		aData.forEach(function(oData) {
			var sValue = oData[sFilterProperty];
			oOrTerm.addExpression({
				name : sFilterProperty,
				operator : "EQ",
				value : sValue
			});
		});
		oPathContextHandler.update(sFilterProperty, oFilter);
		if (!bHasServedBefore) {
			oPathContextHandler.saveInitialContext([ sFilterProperty ]);
		}
		return {
			aData : aData,
			oMetadata : oMetadata
		}; // TO ALLOW METHOD CHAINING.
	};
	this._handleVhrError = function() {
		var oMessageObject = oCoreApi.createMessageObject({
			code : "6010",
			aParameters : [ oCoreApi.getTextNotHtmlEncoded(oFilterTitle) ]
		});
		oCoreApi.putMessage(oMessageObject);
	};
	this._handleFrrError = function() {
		var oMessageObject = oCoreApi.createMessageObject({
			code : "6010",
			aParameters : [ oCoreApi.getTextNotHtmlEncoded(oFilterTitle) ]
		});
		oCoreApi.putMessage(oMessageObject);
		this._resolveSelectDataPromiseWith([], oMessageObject);
	};
};