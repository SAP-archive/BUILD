jQuery.sap.declare("sap.apf.modeler.core.parseTextPropertyFile");
jQuery.sap.require("sap.ui.core.format.DateFormat");
jQuery.sap.require("sap.apf.core.constants");

(function() {
	'use strict';

	/**
	 * @private
	 * @function
	 * @description parses a text property file and returns the text elements and the application id
	 *  plus messages
	 *  @param {string} textFileString property file as string
	 *  @param {object} inject injected instances 
	 * @returns {object} result with properties Application, TextElements, Messages
	 */
	sap.apf.modeler.core.parseTextPropertyFile = function(textFileString, inject) {

		function complain(messageNumber, lineNumber) {
			var message = messageHandler.createMessageObject({
				code : messageNumber,
				aParameters : [ lineNumber ]
			});
			
			parseResult.Messages.push(message);
		}
		function complainWrongFormatApplicationId(lineNumber) {
			complain(11013, lineNumber);
		}

		function complainMissingTextEntry(lineNumber) {
			complain(11011, lineNumber);
		}

		function isValidGuidFormatForTextElement(textElement, lineNumber) {
			var isValid = sap.apf.utils.isValidGuid(textElement);

			if (!isValid) {
				complain(11012, lineNumber);
				return false;
			} else {
				return true;
			}
		}
		
		function complainWrongDateFormat(lineNumber){
			complain(11015, lineNumber);
		}

		function complainInvalidTextEntryGuid(lineNumber) {
			complain(11012, lineNumber);
		}
		
		var messageHandler = inject.instance.messageHandler;
		var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
			pattern : "yyyy/MM/dd HH:mm:ss"
		});
		var oDate;
		var aLines = textFileString.split(/\r?\n/);
		var len = aLines.length;
		var i;
		var indexOfExpectedEntry = -1;
		var indexOfLastChangeDate = -1;
		var textElementEntry;
		var formatWithHint, formatWithoutHint, entry;
		var bApplicationIdFound = false;
		var parseResult = {
			Application : undefined,
			TextElements : [],
			Messages : []
		};

		for(i = 0; i < len; i++) {

			if (!bApplicationIdFound) {

				var applicationId = /^\#\s*ApfApplicationId=[0-9A-F]+\s*$/.exec(aLines[i]);
				if (applicationId !== null) {
					parseResult.Application = aLines[i].split('=')[1];
					if (!sap.apf.utils.isValidGuid(parseResult.Application)) {
						parseResult.Application = "";
						complainWrongFormatApplicationId(i);
					}
					bApplicationIdFound = true;

					continue;
				}
			}

			if (aLines[i] === "") {
				continue;
			}
			
			if (indexOfLastChangeDate === i && /^\#\s*LastChangeDate/.exec(aLines[i])) {
				//# LastChangeDate=2014/10/07 16:30:29
				entry = aLines[i].split('=');
				if (entry.length === 2) {
					oDate = oDateFormat.parse(entry[1]);
					if (!oDate) {
						complainWrongDateFormat(i);
						textElementEntry.LastChangeUTCDateTime = "";
					} else {
						textElementEntry.LastChangeUTCDateTime = '/Date(' + oDate.getTime() + ')/';
					}	
					parseResult.TextElements.push(textElementEntry);
				} else {
					complainWrongDateFormat(i);
				}
				textElementEntry = null;
				continue;
			}

			if (indexOfExpectedEntry === i) {
				entry = aLines[i].split('=');
				if (entry.length === 2) {

					// take over only proper entries
					if (isValidGuidFormatForTextElement(entry[0], i)) {
						textElementEntry.TextElement = entry[0];
						textElementEntry.TextElementDescription = entry[1];
					} else {
						complainInvalidTextEntryGuid(i);
					}

				} else {
					complainMissingTextEntry(i);
				}
				continue;
			}

			formatWithHint = /^\#(X|Y)[A-Z]{3},[0-9]+:/.exec(aLines[i]);
			if (formatWithHint) {
				if (indexOfExpectedEntry === i) {
					complainMissingTextEntry(i);
				}
				textElementEntry = {};
				textElementEntry.Language = sap.apf.core.constants.developmentLanguage;  //Default development language
				textElementEntry.Application = parseResult.Application;
				textElementEntry.TextElementType = aLines[i].match(/(X|Y)[A-Z]{3}/)[0];
				textElementEntry.MaximumLength = aLines[i].match(/,[0-9]+/);
				textElementEntry.MaximumLength = parseInt(textElementEntry.MaximumLength[0].substring(1), 10);
				textElementEntry.TranslationHint = aLines[i].match(/:\s*[0-9a-zA-Z\s]+$/);
				textElementEntry.TranslationHint = textElementEntry.TranslationHint[0].substring(1);

				indexOfExpectedEntry = i + 1;
				indexOfLastChangeDate = i + 2;
			} else {

				formatWithoutHint = /^\#(X|Y)[A-Z]{3},[0-9]+/.exec(aLines[i]);
				if (formatWithoutHint) {
					if (indexOfExpectedEntry === i) {
						complainMissingTextEntry(i);
					}
					textElementEntry = {};
					textElementEntry.Language = sap.apf.core.constants.developmentLanguage;  //Default development language
					textElementEntry.Application = parseResult.Application;
					textElementEntry.TextElementType = aLines[i].match(/(X|Y)[A-Z]{3}/)[0];
					textElementEntry.MaximumLength = aLines[i].match(/,[0-9]+/);
					textElementEntry.MaximumLength = parseInt(textElementEntry.MaximumLength[0].substring(1), 10);
					textElementEntry.TranslationHint = "";
					indexOfExpectedEntry = i + 1;
					indexOfLastChangeDate = i + 2;
				} 
			}
		}
		if (!bApplicationIdFound) {
			complain(11010, 0);
		}
		return parseResult;
	}; 
}()); 