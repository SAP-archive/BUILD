/*
* ! @copyright@
*/

sap.ui.define(["jquery.sap.global","sap/ui/core/mvc/Controller","sap/suite/ui/commons/TimelineItem","sap/m/MessageBox",
               "sap/collaboration/components/utils/LanguageBundle","sap/collaboration/components/utils/DateUtil",
               "sap/collaboration/components/controls/FeedEntryEmbedded","sap/collaboration/components/controls/ReplyPopover","sap/collaboration/components/controls/AddPostPopover"],
	function(jQuery, Controller, TimelineItem, MessageBox,
			LanguageBundle, DateUtil,
			FeedEntryEmbedded, ReplyPopover, AddPostPopover) {
	"use strict";
	var sControllerName = "sap.collaboration.components.feed.views.GroupFeed";
	var sJamServiceUrl = "/sap/bc/ui2/smi/rest_tunnel/Jam/api/v1/OData";
	var sSMIv2ServiceUrl = "/sap/opu/odata/sap/SM_INTEGRATION_V2_SRV";
	
	var oGroupFeed =  Controller.extend(sControllerName, {
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		onInit: function() {
			
			this._initializeUtilities();
			this._initializeControlData();
			this._initializeModels();						
			this._initializeTimeline();
			
			if (this._isJamConfigured()) {
				this._getLoggedInUser();
				this._oSocialProfile = this._createSocialProfile();
			}
		},
		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		onBeforeRendering: function() {
			if (!this._isJamConfigured()) {
				this._displayErrorMessage();
			}
		},
		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		onAfterRendering: function() {
		},
		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		onExit: function() {
			this._abortAllPendingRequests();
		},
		
		
		/************************************************************************
		 * Initialization
		 ************************************************************************/
		/**
		 * Initialize the utility classes that will be needed
		 */
		_initializeUtilities: function() {
			this._oLogger = new jQuery.sap.log.getLogger(sControllerName);
			this._oLanguageBundle = new LanguageBundle();
			this._oDateUtil = new DateUtil();
		},
		/**
		 * Initialize feed component control data
		 */
		_initializeControlData: function() {
			this._oNextLinks = {
					"feedEntriesNextLink": "",
					"repliesNextLink": ""	
				};
			this._oPendingRequests = {
				"loadingGroupInfoRequest": undefined,
				"loadingFeedEntriesRequest": undefined,
				"loadingRepliesRequest": undefined,
				"loadingSuggestionsRequest": undefined
			};
		},
		/**
		 * Create and initialized the models for the view
		 * 1- Jam model: OData model for connecting to Jam
		 * 2- SMI v2 model: OData model for connecting to SMIntegration V2 gateway service
		 * 3- View model: JSON model for the controls' properties
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed 
		 */
		_initializeModels: function() {
			
			// SMIv2 model
			var oSMIModel =  new sap.ui.model.odata.ODataModel(sSMIv2ServiceUrl, {
			});
			this.getView().setModel(oSMIModel, "smi");
			this._oSMIModel = oSMIModel;
			
			// Jam model
			var oJamModel =  new sap.ui.model.odata.v2.ODataModel(sJamServiceUrl);
			oJamModel.attachMetadataFailed(this._onMetadataFailed, this);
			oJamModel.attachRequestCompleted(this._onJamRequestCompleted, this);
			oJamModel.attachRequestFailed(this._onJamRequestFailed, this);
			oJamModel.attachRequestSent(this._onJamRequestSent, this);
			oJamModel.attachBatchRequestCompleted(this._onBatchCompleted, this);
			oJamModel.attachBatchRequestFailed(this._onBatchFailed, this);
			oJamModel.attachBatchRequestSent(this._onBatchSent, this);
			this.getView().setModel(oJamModel, "jam");
			this._oJamModel = oJamModel;
			
			// View Data model
			var oViewDataModel = new sap.ui.model.json.JSONModel(); 
			oViewDataModel.setData({
				"enableSocial": true,
				"axisOrientation": undefined,
				"enableScroll": false,
				"forceGrowing": true,
				"growingThreshold": 10,
				"feedSources": undefined,
				"groupSelectorButtonEnabled": true,
				"groupSelected": {},
				"groups":[],
				"currentUser": {}
			});
			oViewDataModel.bindProperty("/feedSources").attachChange(this._onFeedSourcesChange, this);
			oViewDataModel.bindProperty("/groupSelected/Id").attachChange(this._onGroupSelectedChange, this);
			this.getView().setModel(oViewDataModel);
			this._oViewDataModel = oViewDataModel;
		},
		/**
		 * Create the Context Selector Control
		 * @private
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_createGroupSelector: function(){
			var that = this;

			var onGroupSelectorButtonPress = function(oEvent){
				
				var oGroupSelect = that.byId("group_select_button");

				var oGroupSelectPopover = that.byId("group_select_popover");
				var sGroupId = that._oViewDataModel.getData().groupSelected.Id;

				if (oGroupSelectPopover == undefined ){

					var oGroupSelectItemTemplate = new sap.ui.core.Item({key:"{id}", text:"{name}"});

					var oGroupSelectList = new sap.m.SelectList(that.createId("group_select_list"),{
						selectedKey: sGroupId,
						selectionChange: [that.onGroupSelected, that],
						width: "15rem"
					});
					
					oGroupSelectItemTemplate.setTooltip("{name}");
					oGroupSelectList.bindAggregation("items", { path: "/groups", template: oGroupSelectItemTemplate});
					oGroupSelectList.setModel(that._oViewDataModel);
		
					var oGroupSelectPopover = new sap.m.Popover(that.createId("group_select_popover"),{
						placement: sap.m.PlacementType.VerticalPreferedBottom,
						title: this._oLanguageBundle.getText("ST_GROUP_SELECT_HEADER")
					});
				
					oGroupSelectPopover.addContent(oGroupSelectList);
				}
				oGroupSelectPopover.getContent()[0].setSelectedKey(sGroupId);
				oGroupSelectPopover.openBy(oGroupSelect);

			};
						
			var oGroupSelectButton = new sap.m.Button( this.createId("group_select_button"), { 	
				icon: "sap-icon://navigation-down-arrow",
				iconFirst: false,
				iconDensityAware: false,
				text: "{/groupSelected/Name}",
				textDirection: sap.ui.core.TextDirection.LTR,
				width: "20em",
				enabled: true,
				type: sap.m.ButtonType.Transparent,
				press: [onGroupSelectorButtonPress, this]
			});
			
			return oGroupSelectButton;
		},
		/**
		 * Create the Add Post button
		 * @private
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_createAddPostButton: function(){
			var that = this;
			
			if(this._oAddPostPopover === undefined){
				this.getView()._oAddPostPopover =  new AddPostPopover(this.createId("_addPostPopover"), {
					notifyAllEnabled: true,
					postPress: this.onAddPost.bind(this),
					suggest: [this.onSuggest, this],
					afterSuggestionClose: [function(){
						if(this._oPendingRequests.loadingSuggestionsRequest){
							this._oPendingRequests.loadingSuggestionsRequest.abort();
						}
					}, this]
				});
			}
			var oAddPostButton = new sap.m.Button(this.createId("addPostButton") , {
				icon: "sap-icon://add",
				type: sap.m.ButtonType.Transparent,
				enabled: true,
				press: function(){
					that.getView()._oAddPostPopover.openBy(this);
				}
			});
			
			return oAddPostButton;
		},
		
		
		/************************************************************************
		 * Timeline manipulation
		 ************************************************************************/
		/**
		 * Initialize timeline
		 * @private
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_initializeTimeline: function() {
			var oTimeline = this.byId("timeline");
			oTimeline.setContent([]);
			
			this._modifyHeaderBar();
		},
		/**
		 * Modify the Timeline Header Bar
		 * @private
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_modifyHeaderBar: function(){
			var oHeader = this.byId("timeline").getHeaderBar();
			
			//Remove filter button
			oHeader.removeContent(1);
			
			var oGroupSelectorButton = this._createGroupSelector();
			oGroupSelectorButton.setModel(this.getView().getModel());
			oHeader.insertContent(oGroupSelectorButton, 0);
			
			// create the Add Post button
			var oAddPostButton = this._createAddPostButton();
			oHeader.insertContent(oAddPostButton, 2);
		},
		/**
		 * Clear the timeline of all its content
		 * @private
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_clear: function() {
			var oTimeline = this.byId("timeline");
			oTimeline.destroyContent();
			
		},
		/**
		 * Create a timeline item control
		 * @param oFeedEntry
		 * @private
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_createTimelineItem: function(oFeedEntry) {
			var oFeedEntryModel = new sap.ui.model.json.JSONModel(oFeedEntry);
			var oFeedEntryEmbedded = new FeedEntryEmbedded(this.createId(oFeedEntry.Id+"_embedded"), {
				"feedEntry": "{/}",
				"linkPress": [this.onEmbeddedControlLinkPress, this]
			});
			
			var oReplyPopover = new ReplyPopover({
				notifyAllEnabled: true,
				postReplyPress: [this.onPostReplyPress, this],
				moreRepliesPress: [function(oEvent){
					var oTimelineItem = oEvent.getSource().getParent();
					this._getReplies(undefined, oTimelineItem.getModel().getData().Replies.__next, oTimelineItem);
				}, this],
				suggest: [this.onSuggest, this],
				afterSuggestionClose: [function(){
					if(this._oPendingRequests.loadingSuggestionsRequest){
						this._oPendingRequests.loadingSuggestionsRequest.abort();
					}
				}, this]
			});
			
			var oMoreCustomAction = new sap.ui.core.CustomData({key:"1", value: "More"});
						
			var oTimelineItem = new TimelineItem(this.createId(oFeedEntry.Id), {
				"dateTime": "{/CreatedAt}",
				"userName": "{/Creator/FullName}", 
				"title": "{/Action}",
				"text": "{/Text}",
				"icon": "sap-icon://post",
				"userNameClickable": this._oViewDataModel.getProperty("/enableSocial"),
				"userNameClicked": [this.onUserNameClicked, this],
				"userPicture": {
					parts: [{path : "/Creator/Id", type: new sap.ui.model.type.String()}],
					formatter: this._buildThumbnailImageURL.bind(this)
				},
				"replyCount": "{/RepliesCount}",
				"embeddedControl": oFeedEntryEmbedded,
				"customReply": oReplyPopover,
				"replyListOpen": [this.onReplyListOpen, this],
				"customAction": oMoreCustomAction,
				"customActionClicked": [this.onMoreClicked, this]
			});
			oTimelineItem.setModel(oFeedEntryModel);
			return oTimelineItem;
		},
		/**
		 * Create the Social Profile component
		 * @private
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_createSocialProfile: function(){
			var oSocialProfileComponent = new sap.ui.getCore().createComponent("sap.collaboration.components.socialprofile");
			this.getView().byId("socialProfileContainer").setComponent(oSocialProfileComponent);
			return oSocialProfileComponent;
		},
		/**
		 * Sets the busy indicator for the Timeline control
		 * @private
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_setTimelineToBusy: function(){
			var oTimeline = this.byId("timeline");
			oTimeline.setBusyIndicatorDelay(0).setBusy(true);
			
			var oGroupSelector = this.byId("group_select_button");
			oGroupSelector.setBusyIndicatorDelay(0).setBusy(true);
		},
		/**
		 * Turn off the busy indicator for the Timeline control
		 * @private
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_setTimelineToNotBusy: function(){
			var oTimeline = this.byId("timeline");
			oTimeline.setBusyIndicatorDelay(0).setBusy(false);
			
			var oGroupSelector = this.byId("group_select_button");
			oGroupSelector.setBusyIndicatorDelay(0).setBusy(false);
		},
		
		/************************************************************************
		 * Controls event handlers
		 ***********************************************************************/
		/**
		 * Event handler for the "Show More" button of the Timeline Control
		 * @param oEvent
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		onGrow: function(oEvent) {
			// if there's a pending request, do not start a new one
			if(!this._oPendingRequests.loadingFeedEntriesRequest || 
					!this._oPendingRequests.loadingFeedEntriesRequest.state() != "pending") {
				this._loadFeedEntries();	
			}
		},
		/**
		 * Event handler when group selected has changed
		 * @param oEvent
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		onGroupSelected: function(oEvent) {			
			var oGroupSelected = oEvent.getSource().getSelectedItem().getBindingContext().getObject();

			this._oViewDataModel.setProperty("/groupSelected/Id", oGroupSelected.id);
			this._oViewDataModel.setProperty("/groupSelected/Name", oGroupSelected.name);
			this._oViewDataModel.setProperty("/groupSelected/WebURL", oGroupSelected.webUrl);

			oEvent.getSource().getParent().close();
		},
		/**
		 * Event handler for the add post button. Opens a pop over to add a post.
		 * @param oEvent
		 * @public
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		onAddPost: function(oEvent){
			var that = this;		
			var sContent = oEvent.getParameter("value");
			
			// post the user content if it's not empty
			if(sContent && sContent.trim() !== ""){
				var oTimeline = this.byId("timeline");
				oTimeline.setBusyIndicatorDelay(0).setBusy(true);
				
				var sGroupId = this._oViewDataModel.getProperty("/groupSelected/Id");
				var sPath = "/Groups('"+ jQuery.sap.encodeURL(sGroupId) +"')/FeedEntries";
				var addPostPromise = jQuery.Deferred();
				var oData = {"Text" : sContent};
				var mParameters = {}; 
				
				mParameters.success = function(oData, response){
					addPostPromise.resolveWith(that, [oData,response]);
				};
				
				mParameters.error = function(oError) {
					addPostPromise.rejectWith(that, [oError]);
				};
				
				addPostPromise.done(function(oData, response){
					var oFeedEntry = oData.results;
					oFeedEntry.Creator.FullName = that._oViewDataModel.getProperty("/currentUser/FullName");
					oFeedEntry.Creator.Id = that._oViewDataModel.getProperty("/currentUser/Id");
					oFeedEntry.Creator.Email = that._oViewDataModel.getProperty("/currentUser/Email");
					
					var oTimelineItem = that._createTimelineItem(oFeedEntry);
					oTimeline.addContent(oTimelineItem);
				})
				.always(function(){
					oTimeline.setBusy(false);
					this._oJamModel.setUseBatch(true);
				})
				.fail(function(){
					that._displayErrorMessage(that._oLanguageBundle.getText("ST_POST_TO_JAM_FAILED"));
				});
				
				this._oJamModel.setUseBatch(false);
				var oContext = this._oJamModel.create(sPath, oData, mParameters);
				this._oJamModel.submitChanges();
			}
			else {
				this._oLogger.info('Posting an empty comment is not allowed, no feed entry will be created.');
			}
		},
		/**
		 * Event handler when the ReplyPopover is opened.
		 * @param oEvent
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		onReplyListOpen: function(oEvent){
			var oTimelineItem = oEvent.getSource();
			var sFeedId = oTimelineItem.getModel().getData().Id;
			this._getReplies(sFeedId, undefined, oTimelineItem);
		},
		/**
		 * Event handler when the "Post" button is pressed on the ReplyPopover.
		 * @param oEvent
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		onPostReplyPress: function(oEvent){
			var that = this;
			var bIsOkToRefreshSecurityToken = true;
			var sValue = oEvent.getParameter("value");
			var oTimelineItem = oEvent.getSource().getParent();
			var sFeedId = oTimelineItem.getModel().getData().Id;
			var sPath = "/FeedEntries('" + jQuery.sap.encodeURL(sFeedId) + "')/Replies";
			var postingReplyPromise = jQuery.Deferred();
			var oDataPayload = {"Text" : sValue};
			var mParameters = {
				"async": true,
				"success": function(oData, response){
					that._oLogger.info("The reply was successfully posted.");
					postingReplyPromise.resolveWith(that, [oData,response]);
				},
				"error": function(oError){
					that._oLogger.error("Failed to post reply: " + oError.statusText);
					postingReplyPromise.rejectWith(that, [oError]);
				}
			};
			
			postingReplyPromise.done(function(oData, response){
				var oJamResults = oData.results;
				var oReply = {
						Creator : {}
				};
				oReply.Text = oJamResults.Text;
				oReply.Creator.ThumbnailImage = this._buildThumbnailImageURL(this._oViewDataModel.getProperty("/currentUser/Id"));
				oReply.CreatedAt = this._oDateUtil.formatDateToString(oJamResults.CreatedAt);
				oReply.Creator.Email= this._oViewDataModel.getProperty("/currentUser/Email");
				oReply.Creator.FullName = this._oViewDataModel.getProperty("/currentUser/FullName");
				
				oTimelineItem.getCustomReply().addReply(oReply);
				
				oTimelineItem.getModel().setProperty("/RepliesCount", oTimelineItem.getModel().getProperty("/RepliesCount") + 1);
			})
			.always(function(){
				oTimelineItem.getCustomReply().setBusy(false);
				this._oJamModel.setUseBatch(true);
			})
			.fail(function(oError){
				if(oError.statusCode === 403 && bIsOkToRefreshSecurityToken){
					this._oJamModel.refreshSecurityToken(
							function(){
								bIsOkToRefreshSecurityToken = false;
								that._oJamModel.create(sPath, oDataPayload, mParameters);
							},
							function(oRefreshSecurityTokenError){
								that._oLogger.error("Failed to post reply: " + oRefreshSecurityTokenError.statusText);
							},
							true
						);
				}
				else {
					this._displayErrorMessage(this._oLanguageBundle.getText("ST_POST_REPLY_FAILED"));
				}
			});
			
			// We need to put the focus on the text area to avoid the Popover from closing - not sure why it closes
			oTimelineItem.getCustomReply()._oReplyTextArea.focus();
			oTimelineItem.getCustomReply().setBusyIndicatorDelay(0).setBusy(true);
			this._oJamModel.setUseBatch(false);
			this._oJamModel.create(sPath, oDataPayload, mParameters);
		},
		/**
		 * Event handler for the suggestions
		 * @param {object} oEvent
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		onSuggest: function(oEvent){
			var that = this;
			
			if(this._oPendingRequests.loadingSuggestionsRequest){
				this._oPendingRequests.loadingSuggestionsRequest.abort();
			}
			var oPopover;
			var oSource = oEvent.getSource();
			oSource.getMetadata().getName() === "sap.collaboration.components.controls.AddPostPopover" ? 
					oPopover = this.getView()._oAddPostPopover : oPopover = oSource.getParent().getCustomReply();
					
			var sValue = oEvent.getParameter("value");
			if(sValue.trim() === ""){ // if value is empty then it's the suggestions is triggered but user has not entered any text yet
				oPopover.setSuggestionData([]);
			}
			else {
				var sPath = "/Members_Autocomplete";
				var sGroupId = this._oViewDataModel.getProperty("/groupSelected/Id");
				var mParameters = {
					"async": true,
					"urlParameters": {
						"Query": "'" + sValue + "'",
						"GroupId": "'" + sGroupId + "'"
					},
					"success": function(oData, response){
						gettingSuggestionsPromise.resolveWith(that, [oData,response]);
					},
					"error": function(oError){
						that._oLogger.error("Failed to get suggestions: " + oError.statusText);
						gettingSuggestionsPromise.rejectWith(that, [oError]);
					}
				};
				
				var gettingSuggestionsPromise = jQuery.Deferred();
				gettingSuggestionsPromise.done(function(oData, response){
					var aJamResults = oData.results;
					if(aJamResults.length === 0){ // if nothing is returns from jam then close the suggestion popover
						oPopover.closeSuggestionPopover();
					}
					else {
						var aSuggestions = [];
						var iJamResultsLength = aJamResults.length;
						for(var i = 0; i < iJamResultsLength; i++){
							aSuggestions.push({
								fullName: aJamResults[i].FullName,
								email: aJamResults[i].Email,
								userImage: that._buildThumbnailImageURL(aJamResults[i].Id)
							});
						}
						oPopover.setSuggestionData(aSuggestions);
					}
				})
				.always(function(){
					that._oJamModel.setUseBatch(true);
				})
				.fail(function(oError){
					// we need this check since an aborted request also causes an error, but doesn't have a status code and should not be treated as an error
					if(oError && oError.statusCode){
						that._displayErrorMessage(that._oLanguageBundle.getText("ST_GET_SUGGESTIONS_FAILED"));
					}
				});
				this._oJamModel.setUseBatch(false);
				this._oPendingRequests.loadingSuggestionsRequest = gettingSuggestionsPromise.promise(this._oJamModel.read(sPath, mParameters));
			}
		},
		/**
		 * Event handler for userNameClicked event
		 * @param {object} oControlEvent - event when the user name is clicked
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		onUserNameClicked: function(oControlEvent){
			var oTimelineEntry = oControlEvent.getSource();
			var oTimelineEntryModel = oTimelineEntry.getModel(); 
			var oSettings = {
					openingControl: oTimelineEntry._userNameLink,
					memberId: oTimelineEntryModel.getData().Creator.Email
			};
			this._oSocialProfile.setSettings(oSettings);
			this._oSocialProfile.open();
		},
		/**
		 * Event handler for the more custom action. Opens a pop over that contain links to the group and feed entry.
		 * @param oEvent
		 * @public
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */		
		onMoreClicked: function(oEvent){
			var sFeedEntryWebURL  = oEvent.getSource().getModel().getProperty("/WebURL");		
			var sFeedEntryId = oEvent.getSource().getModel().getProperty("/Id");
			
			var sSelectedGroupName = oEvent.getSource().getParent().getModel().getProperty("/groupSelected/Name");	
			var sSelectedGroupWebURL = oEvent.getSource().getParent().getModel().getProperty("/groupSelected/WebURL");	

			var oMorePopover = this.byId(this.createId("moreListPopover_" + sFeedEntryId));
			
			if(oMorePopover === undefined){
				var oMoreList = new sap.m.List(this.createId("moreList_" + sFeedEntryId), {});
	         
		        var oGroupNameLink = new sap.m.Link(this.createId("groupNameLink_" + sFeedEntryId), {
		        	text: this._oLanguageBundle.getText("ST_GROUP_NAME_LINK", sSelectedGroupName),
		            target: "_blank",
		            href: sSelectedGroupWebURL,
	                width: "15em"
		        }).addStyleClass("sapCollaborationCustomLinkPadding");
		         
		        var oGroupNameLinkListItem = new sap.m.CustomListItem(this.createId( sFeedEntryId + "_groupNameLinkListItem" ), {
		            content: oGroupNameLink
		        });
		         
		        oMoreList.addItem(oGroupNameLinkListItem);
	            
	            var oFeedEntryLink = new sap.m.Link(this.createId("feedEntryLink_" + sFeedEntryId), {
	                 text: this._oLanguageBundle.getText("ST_FEED_ENTRY_LINK"),
	                 target: "_blank",
	                 href: sFeedEntryWebURL,
		                width: "15em"
	            }).addStyleClass("sapCollaborationCustomLinkPadding");
	            
	            var oFeedEntryLinkListItem = new sap.m.CustomListItem(this.createId("feedEntryLinkListItem_" + sFeedEntryId), {
	                 content: oFeedEntryLink
	            });
	            
	            oMoreList.addItem(oFeedEntryLinkListItem);
	            
	            oMorePopover = new sap.m.ResponsivePopover(this.createId("moreListPopover_" + sFeedEntryId), {
	                content: oMoreList,
	                showHeader: false,
	                placement: sap.m.PlacementType.VerticalPreferedBottom,
	                offsetX: 40,
	                offsetY: -25
	            });
			};
            oMorePopover.openBy(oEvent.getSource());
		},
		/**
		 * Event handler when a username in the embedded control is clicked
		 * @param {object} oEvent - event when the user name is clicked
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		onEmbeddedControlLinkPress: function(oEvent){
			var that = this;
			var sPath = "/FeedEntries('" + jQuery.sap.encodeURL(oEvent.getParameter("feedid")) + "')/AtMentions";
			var sFullName = oEvent.getParameter("fullname");
			var oUserNameLink = oEvent.getParameter("link");
			var mParameters = {
					"async": true,
					"success": function(oData, response){
						getAtMentionsPromise.resolveWith(that, [oData,response]);
					},
					"error": function(oError){
						that._oLogger.error('Failed to retrieve the @mentions.');
						getAtMentionsPromise.rejectWith(that, [oError]);
					}
				};

			var getAtMentionsPromise = jQuery.Deferred();
			getAtMentionsPromise.done(function(oData, response){
				var aJamResults = oData.results;
				aJamResults.forEach(function(oAtMention){
					if(oAtMention.FullName === sFullName){
						var oSettings = {
								openingControl: oUserNameLink,
								memberId: oAtMention.Email
						};
						that._oSocialProfile.setSettings(oSettings);
						that._oSocialProfile.open();
					}
				});
			}).always(function(){
				that._oJamModel.setUseBatch(true);
			});
			getAtMentionsPromise.fail(function(oError){
				that._displayErrorMessage(that._oLanguageBundle.getText("ST_GET_ATMENTIONS_FAILED"));
			});
			
			this._oJamModel.setUseBatch(false);
			this._oJamModel.read(sPath, mParameters);
		},
		/************************************************************************
		 * Error handling
		 ************************************************************************/
		/**
		 * Display error message
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_displayErrorMessage: function(sErrorText) { 
			var sMessage = sErrorText || this._oLanguageBundle.getText("SYSTEM_ERROR_MESSAGEBOX_GENERAL_TEXT");
			
			MessageBox.error(sMessage);
		},
		/**
		 * Display Jam connection error
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_displayJamConnectionErrorMessage: function() { 
			var sMessage = this._oLanguageBundle.getText("JAM_CONNECTION_ERROR_MESSAGEBOX_TEXT");
			
			MessageBox.error(sMessage);
		},
		/**
		 * Destroys and clean up the Timeline
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed 
		 */
		_shutdownGroupFeed: function(){
			this._abortAllPendingRequests();
			var oTimeline = this.byId("timeline");
			if(!jQuery.isEmptyObject(oTimeline)){
				oTimeline.setBusyIndicatorDelay(0).setBusy(false);
				oTimeline.setVisible(false);		
			}
		},		
		
		/************************************************************************
		 * Requests
		 ************************************************************************/
		/**
		 * Abort all pending requests
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_abortAllPendingRequests: function() {
			if(this._oPendingRequests.loadingGroupsRequest) {
				this._oPendingRequests.loadingGroupRequest.abort();
			}
			if(this._oPendingRequests.loadingFeedEntriesRequest) {
				this._oPendingRequests.loadingFeedEntriesRequest.abort();
			}
			if(this._oPendingRequests.loadingRepliesRequest) {
				this._oPendingRequests.loadingRepliesRequest.abort();
			}
			if(this._oPendingRequests.loadingSuggestionsRequest) {
				this._oPendingRequests.loadingSuggestionsRequest.abort();
			}
		},
		/**
		 * Check Jam configuration of
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_isJamConfigured: function(){
			var oSMIModel = this.getView().getModel("smi");
			this.bIsJamConfigured;
			if (this.bIsJamConfigured == undefined) {
				var that = this;
				var sPath = "/GetJamConfigurationStatus";
				var checkingJamConfigurationPromise = jQuery.Deferred();
				var mParameters = {
					"async": false,
					"success": function(oData, response){
						that.bIsJamConfigured = true;
					},
					"error": function(oError){
						that.bIsJamConfigured = false;
						that._oLogger.error("Error in the Social Media Integration configuration for the connection to SAP Jam.")
						that._shutdownGroupFeed();
					}
				};
				oSMIModel.read(sPath, mParameters);
			}
			
			return this.bIsJamConfigured;
		},
		/**
		 * Get the logged in user from Jam and assign it to a member attribute of the controller.
		 * @private
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_getLoggedInUser: function(){
			var that = this;
			var sPath = "/Self";
			var mParameters = {
					
			};
			var getSelfPromise = jQuery.Deferred();
			
			mParameters.success = function(oData, response){
				getSelfPromise.resolveWith(that, [oData,response]);
			};
			
			mParameters.error = function(oError){
				getSelfPromise.rejectWith(that, [oError]);
			};
			
			this._oJamModel.read(sPath, mParameters);
			
			getSelfPromise.done(function(oData, response){
				that._oViewDataModel.setProperty("/currentUser",oData.results);
				
			});
			
			getSelfPromise.fail(function(oError){
				that._oLogger.error('Failed to get the logged in user', oError.stack);
				//that._oCommonUtil.displayError(that._oLanguageBundle.getText('ST_POST_REPLY_FAILED')); 
			});
		},
		/**
		 * Fetches a single group's information
		 * @param {string} groupId 
		 * @private
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_loadGroupInfo: function(groupId, index) {
			var that = this;
			
			var loadingGroupInfo = jQuery.Deferred();
			
			var sPath ="/Groups('"+ groupId +"')";
			var mParameters = {
				"success": function(oData, response) {
					loadingGroupInfo.resolveWith(that, [oData,response]);
				}, 
				"error": function(oError) {
					loadingGroupInfo.rejectWith(that, [oError]);
					that._oLogger.error("The group information was not retrieved.");
				}
			}
			
			//this._oPendingRequests.loadingGroupInfoRequest;
			return loadingGroupInfo.promise(this._oJamModel.read(sPath,mParameters));
		},
		/**
		 * Load the feed entries for the selected group. If a next link exists, get the next page.
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_loadFeedEntries: function() {
			// if Jsm is not configured, do not execute
			if (!this._isJamConfigured()) {
				return;
			}
			
			this._setTimelineToBusy();
			
			var sGroupId = this._oViewDataModel.getProperty("/groupSelected/Id");
			var sPath ="/Groups('"+sGroupId+"')/FeedEntries";
			var mParameters = {
				"urlParameters":{
					"$expand": "Creator,TargetObjectReference"
				}
			};
			
			// resolve next link
			var sNextLink = decodeURIComponent(this._oNextLinks.feedEntriesNextLink);
			if(sNextLink === undefined) {
				return;
			}
			else if(sNextLink != "") {
				mParameters.urlParameters = this._extractUrlParams(sNextLink);
			}
			
			// prepare a promise  
			var loadingFeedEntriesPromise = jQuery.Deferred();
			var that = this;
			mParameters.success = function(oData, response) {
				loadingFeedEntriesPromise.resolveWith(that, [oData,response]);
			}, this;
			mParameters.error = function(oError) {
				loadingFeedEntriesPromise.rejectWith(that, [oError]);
			};
			
			loadingFeedEntriesPromise.done(function(oData,response){
				var oTimeline = this.byId("timeline");

				this._oNextLinks.feedEntriesNextLink = oData.__next; // save next link
				
				// create timeline item controls for each feed entry and add it to the timeline
				var aFeedEntries = oData.results;
				aFeedEntries.forEach( function(oFeedEntry){
					try {
						var oTimelineItem = this._createTimelineItem(oFeedEntry);
						oTimeline.addContent(oTimelineItem);
					}
					catch(err) {
						// skip this duplicate feed entry and continue
					}
				}, this);
			});
			loadingFeedEntriesPromise.fail(function(oError){
				
			});
			return this._oPendingRequests.loadingFeedEntriesRequest = loadingFeedEntriesPromise.promise(this._oJamModel.read(sPath, mParameters));
		},
		/**
		 * Get the Replies based on whether the sFeedEntryId or sNextLink is passed:
		 * i- If the sFeedEntryId is passed, then the assumption is that it's the initial set of replies
		 * ii- If the sNextLink is passed, then the assumption is that the "Show More" link is pressed and the next link from SAP Jam is used
		 * to make the call to retrieve the next set of Replies
		 * 
		 * @param {string} sFeedId - the feed entry id
		 * @param {string} sNextLink - the next link from SAP Jam
		 * @param {object} oTimelineItem - the timeline item that corresponds to this Reply
		 * @private
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_getReplies: function(sFeedId, sNextLink, oTimelineItem) { 
			var that = this;
			var sPath;
			var mParameters = {
				"async": true,
				"urlParameters": {
						'$orderby': 'CreatedAt desc',
						'$expand': 'Creator'
				},
				"success": function(oData, response){
					that._oLogger.info("Replies were successfully retrieved.");
					gettingRepliesPromise.resolveWith(that, [oData,response]);
				},
				"error": function(oError){
					that._oLogger.error("Failed to retrieve replies: " + oError.statusText);
					gettingRepliesPromise.rejectWith(that, [oError]);
				}
			};
			
			if(sNextLink){
				sPath = "/" + sNextLink;
				mParameters.urlParameters = this._extractUrlParams(decodeURIComponent(sNextLink));
				mParameters.urlParameters.$orderby = mParameters.urlParameters.$orderby.replace("+", " ");
			}
			else {
				sPath = "/FeedEntries('" + jQuery.sap.encodeURL(sFeedId) + "')/Replies";
			}
			
			var gettingRepliesPromise = jQuery.Deferred();
			gettingRepliesPromise.done(function(oData, response){
				var aReplies = oData.results.reverse();
				
				// for each reply, build the image url and format the date
				aReplies.forEach(function(oReply){
					oReply.Creator.ThumbnailImage = that._buildThumbnailImageURL(oReply.Creator.Id);
					oReply.CreatedAt = that._oDateUtil.formatDateToString(oReply.CreatedAt);
				});
				
				oTimelineItem.getCustomReply().addReplies({
					data : aReplies,
					more : oData.__next ? true : false
				});
				oTimelineItem.getModel().getData().Replies.__next = oData.__next;
			})
			.always(function(){
				oTimelineItem.getCustomReply().setBusy(false);
				that._oJamModel.setUseBatch(true);
			})
			.fail(function(oError){
				that._displayErrorMessage(that._oLanguageBundle.getText('ST_GET_REPLIES_FAILED')); 
			});
			
			oTimelineItem.getCustomReply().setBusyIndicatorDelay(0).setBusy(true);
			this._oJamModel.setUseBatch(false);
			this._oJamModel.read(sPath, mParameters);
		},
		/************************************************************************
		 * View model's event handlers
		 ************************************************************************/
		/**
		 * Event handler for when the property /groupSelected/Id is changed
		 * @param oEvent
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_onGroupSelectedChange: function(oEvent) {
			
			
			if(this._oPendingRequests.loadingFeedEntriesRequest) {
				this._oPendingRequests.loadingFeedEntriesRequest.abort();
			}
			this._initializeControlData();
			this._clear();
			this._loadFeedEntries();
		},
		/**
		 * Event handler for when the property feedSources changes
		 * @param oEvent
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_onFeedSourcesChange: function(oEvent) {
			var aFeedSources = oEvent.getSource().getValue();
			
			if (Array.isArray(aFeedSources)) {
				var aGroups = [];

				aFeedSources.forEach(function(groupId, index){
					aGroups.push({"id": groupId, "name": "", "webUrl": ""});
					this._loadGroupInfo(groupId, index).done(function(oData,response) {
						this._oViewDataModel.setProperty("/groups/" + index + "/name", oData.results.Name);
						this._oViewDataModel.setProperty("/groups/" + index + "/webUrl", oData.results.WebURL);
						
						if (index == 0) {
							this._oViewDataModel.setProperty("/groupSelected/Name", oData.results.Name);
							this._oViewDataModel.setProperty("/groupSelected/WebURL", oData.results.WebURL);
						}
					})
				}, this);
				
				// Set the selected group to the first group
				this._oViewDataModel.setProperty("/groups", aGroups);
				this._oViewDataModel.setProperty("/groupSelected/Id", aGroups[0].id);
				this._oViewDataModel.setProperty("/groupSelected/Name", aGroups[0].name);
				this._oViewDataModel.setProperty("/groupSelected/WebURL", aGroups[0].webUrl);
			}
			else{
				this._oLogger.error("The paramater feedSources is not valid.");
				this._displayErrorMessage();
			}
		},
		
		/************************************************************************
		 * SM Integration V2 model's event handlers
		 ************************************************************************/
		/**
		 * Event handler for when Jam or SMI fail to load their metadata
		 * @param oEvent
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */ 
		_onMetadataFailed: function(oEvent) {
			
			switch(oEvent.oSource.sServiceUrl) {
			case sJamServiceUrl:
				this._oLogger.error("Failed to load Jam metadata.");
				this._displayJamConnectionErrorMessage();
				break;
				
			case sSMIv2ServiceUrl:
				this._oLogger.error("Failed to load SMIv2 metadata.");
				this._displayErrorMessage();
				break;
			}
			this._shutdownGroupFeed();
		},
		
		/************************************************************************
		 * Jam model's event handlers
		 ************************************************************************/
		/**
		 * Event handler for when the requests to Jam are completed
		 * @param oEvent
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_onJamRequestCompleted: function(oEvent) {
			this._setTimelineToNotBusy();
		},
		/**
		 * Event handler for when the requests to Jam fail
		 * @param oEvent
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_onJamRequestFailed: function(oEvent) {
			this._setTimelineToNotBusy();
			this._displayJamConnectionErrorMessage();
		},
		/**
		 * Event handler for when the requests to Jam is sent
		 * @param oEvent
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_onJamRequestSent: function(oEvent) {
		},
		/**
		 * Event handler for when the requests to Jam batch call is completed
		 * @param oEvent
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_onBatchCompleted: function(oEvent) {
		},
		/**
		 * Event handler for when the requests to Jam batch call fails
		 * @param oEvent
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_onBatchFailed: function(oEvent) {
		},
		/**
		 * Event handler for when the requests to Jam batch call is sent
		 * @param oEvent
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_onBatchSent: function(oEvent) {
		},
		/************************************************************************
		 * Utilities
		 ************************************************************************/
		/**
		 * Returns a map containing URL parameters extracted from a URL
		 * @param {string} sURL
		 * @return {map} mUrlParameters
		 * @private
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_extractUrlParams: function(sURL) {
			var sUrlParameters = sURL.slice(sURL.indexOf("?")+1);
			var aUrlParameters = sUrlParameters.split("&");
			var mUrlParameters = {};
			
			aUrlParameters.forEach(function(urlParameter) {
				var indexOfEqual = urlParameter.indexOf("=");
				mUrlParameters[urlParameter.slice(0, indexOfEqual)] = urlParameter.slice(indexOfEqual+1);
			});
			return mUrlParameters;
		},
		/**
		 * Returns a URL for the ThumbnailImage
		 * @param {string} sUserId
		 * @return {string}
		 * @private
		 * @memberOf sap.collaboration.components.feed.views.GroupFeed
		 */
		_buildThumbnailImageURL: function(sUserId) {
			return this._oJamModel.sServiceUrl + "/Members('" + jQuery.sap.encodeURL(sUserId) + "')/ThumbnailImage/$value";
		},
	});
	return oGroupFeed;
}, /* bExport= */ true);
