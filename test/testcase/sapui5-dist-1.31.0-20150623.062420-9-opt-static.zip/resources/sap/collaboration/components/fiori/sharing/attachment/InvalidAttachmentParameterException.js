/*!
 * @copyright@
 */
jQuery.sap.declare("sap.collaboration.components.fiori.sharing.attachment.InvalidAttachmentParameterException");sap.ui.base.Object.extend("sap.collaboration.components.fiori.sharing.attachment.InvalidAttachmentParameterException",{constructor:function(p){this.exceptionName="InvalidAttachmentParameterException: "+p;}});
