/*!
 * @copyright@
 */
jQuery.sap.declare("sap.collaboration.components.fiori.sharing.attachment.InvalidAttachmentConstructorArgumentsException");sap.ui.base.Object.extend("sap.collaboration.components.fiori.sharing.attachment.InvalidAttachmentConstructorArgumentsException",{constructor:function(){this.exceptionName="InvalidAttachmentConstructorArgumentsException";}});
