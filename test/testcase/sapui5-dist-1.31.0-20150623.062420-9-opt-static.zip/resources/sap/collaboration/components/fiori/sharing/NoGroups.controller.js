/*!
 * @copyright@
 */
jQuery.sap.require("sap.collaboration.components.utils.CommonUtil");sap.ui.controller("sap.collaboration.components.fiori.sharing.NoGroups",{onInit:function(){},onBeforeRendering:function(){},onAfterRendering:function(){},onExit:function(){this.getView().destroyContent();}});
