/*!
 * @copyright@
 */
sap.ui.jsview("sap.collaboration.components.fiori.feed.splitApp.SplitApp",{getControllerName:function(){return"sap.collaboration.components.fiori.feed.splitApp.SplitApp";},createContent:function(c){this.sPrefixId=this.getViewData().controlId;this.oSplitApp=new sap.m.SplitApp(this.sPrefixId+"splitApp");return this.oSplitApp;}});
