/*!
 * @copyright@
 */
sap.ui.jsview("sap.collaboration.components.fiori.feed.app.App",{getControllerName:function(){return"sap.collaboration.components.fiori.feed.app.App";},createContent:function(c){this.sPrefixId=this.getViewData().controlId;this.oApp=new sap.m.App(this.sPrefixId+"app");return this.oApp;}});
