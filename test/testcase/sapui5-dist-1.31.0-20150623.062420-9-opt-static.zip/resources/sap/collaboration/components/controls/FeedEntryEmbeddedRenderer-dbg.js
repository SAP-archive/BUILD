/**
 * ! @copyright@
 */
sap.ui.define([],
	function(){
	/**
	 * FeedEntryEmbedded renderer.
	 * @namespace
	 */
	var FeedEntryEmbeddedRenderer = {};
	
	/**
	 * Renders the HTML for the given control, using the provided {@link sap.ui.core.RenderManager}.
	 * @protected
	 * @param {sap.ui.core.RenderManager} oRM the RenderManager that can be used for writing to the render output buffer.
	 * @param {sap.ui.core.Control} oControl an object representation of the control that should be rendered.
	 */
	FeedEntryEmbeddedRenderer.render = function(oRm, oFeedEntryEmbedded){

		// The embedded control is divided into 2 parts:
		// 1-Timeline Item Text Display: Text Display of for the feed and timeline entries
		// 2-Timeline Item Content:	The Content contains the content from feed entries (e.g. document, picture, poll)
		
		
		var iNumberTimelineItemTextControls = oFeedEntryEmbedded._getTimelineItemTextControls().length;
		var iNumberTimelineItemContent = oFeedEntryEmbedded._getTimelineItemContent().getItems().length;
		
		// Timeline Item Text Display
		if ( iNumberTimelineItemTextControls > 0 ){
			oFeedEntryEmbedded._renderTimelineItemText(oRm);
		}
		if ( iNumberTimelineItemTextControls > 0 && iNumberTimelineItemContent > 0 ){
			oRm.write("<br/>");
		}
		// Timeline Item Content
		if ( iNumberTimelineItemContent > 0){
			oRm.renderControl(oFeedEntryEmbedded._getTimelineItemContent());
		}
	};
	
	return FeedEntryEmbeddedRenderer;
}, /* bExport= */ true);


