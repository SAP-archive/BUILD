/**
 * ! @copyright@
 */
sap.ui.define([],function(){var F={};F.render=function(r,f){var n=f._getTimelineItemTextControls().length;var N=f._getTimelineItemContent().getItems().length;if(n>0){f._renderTimelineItemText(r);}if(n>0&&N>0){r.write("<br/>");}if(N>0){r.renderControl(f._getTimelineItemContent());}};return F;},true);
