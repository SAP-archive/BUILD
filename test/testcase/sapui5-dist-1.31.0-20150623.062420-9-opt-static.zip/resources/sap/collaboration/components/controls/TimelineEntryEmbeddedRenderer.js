/**
 * ! @copyright@
 */
sap.ui.define([],function(){var T={};T.render=function(r,t){var n=t._getTimelineItemTextControls().length;if(n>0){t._renderTimelineItemText(r);}};return T;},true);
