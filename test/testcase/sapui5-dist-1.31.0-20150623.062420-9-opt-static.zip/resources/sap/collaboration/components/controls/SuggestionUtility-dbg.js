/*
* ! @copyright@
*/

jQuery.sap.require("sap.collaboration.components.utils.LanguageBundle");
sap.ui.base.Object.extend("sap.collaboration.components.controls.SuggestionUtility", {
});

/**
* Returns the language bundle
* @public
* @return {object}
* @memberOf sap.collaboration.components.controls.SuggestionUtility
*/
sap.collaboration.components.controls.SuggestionUtility.getLangBundle = function() {
	this._oLangBundle = this._oLangBundle || new sap.collaboration.components.utils.LanguageBundle();

	return this._oLangBundle;
};

/**
* Logic for maintaining the the indices for an AtMention in the buffer
* @public
* @param {object} oAtMention
* @param {integer} iLength
* @memberOf sap.collaboration.components.controls.SuggestionUtility
*/
sap.collaboration.components.controls.SuggestionUtility.maintainAtMentionIndices = function(oAtMention, iLength) {
	oAtMention.startIndex = oAtMention.startIndex + iLength;
	oAtMention.endIndex = oAtMention.endIndex + iLength;
};

/**
* Logic to get the change information that happened on the text of the TextArea
* the returned change is an object that has the following information:
* 1. operation : whether the change is add character(s) or delete character(s)
* 2. charsAdded: the characters added in case the operation was add character(s)
* 3. changeIndex: the index where the change starts to happen
* 4. charDiff: number of added or deleted character(s)  
* @public
* @param {string} sTextAreaCurrentValue
* @param {string} sTextAreaOldValue 
* @returns {object}
* @memberOf sap.collaboration.components.controls.SuggestionUtility
*/
sap.collaboration.components.controls.SuggestionUtility.getTextAreaChange = function(sTextAreaCurrentValue, sTextAreaOldValue) {
	if (sTextAreaOldValue !== ""){
		// the loop counter will be the length of the longest string between sTextAreaCurrentValue and sTextAreaOldValue
		var iLoopCounter = sTextAreaCurrentValue.length > sTextAreaOldValue.length ? sTextAreaCurrentValue.length : sTextAreaOldValue.length;
		// get the number of added or deleted characters to the text of the TextArea 
		var iCharDiff = sTextAreaCurrentValue.length > sTextAreaOldValue.length ? sTextAreaCurrentValue.length - sTextAreaOldValue.length  : sTextAreaOldValue.length - sTextAreaCurrentValue.length;
		// function to return a string that represents the added characters to the text of the TextArea
		
		var fGetAddedChars = function(iCharDiff, iStartingIndex) {
			return sTextAreaCurrentValue.substring(iStartingIndex, iStartingIndex + iCharDiff);
		};
		var fGetRemovedChars = function(iCharDiff, iStartingIndex) {
			return sTextAreaOldValue.substring(iStartingIndex, iStartingIndex + iCharDiff);
		};
		// loop to compare character by character between the TextArea text before the change and the TextArea text after the change
		for(var i=0; i<iLoopCounter; i++){
			// if there is a difference 
			if(sTextAreaCurrentValue[i] !== sTextAreaOldValue[i]){
				// if the TextArea text after the change is > then the TextArea text before the change, then character(s) are added, otherwise characters are deleted 
				return sTextAreaCurrentValue.length > sTextAreaOldValue.length ?  
						{operation: "addChar", charsAdded: fGetAddedChars(iCharDiff, i), changeIndex: i, charDiff: iCharDiff} : {operation: "deleteChar", charsRemoved: fGetRemovedChars(iCharDiff, i), changeIndex: i, charDiff: iCharDiff};
			}
		}
	}
	else {
		return {operation: "addChar", charsAdded: sTextAreaCurrentValue, changeIndex: 0};
	}
};

/**
* Converts a text that contains full names to email aliases
* @public
* @param {string} sValue - value of the AddPost Text Area with the full names
* @returns {string} sTextWithAlias - new text with the user's email alias instead of full name
* @memberOf sap.collaboration.components.controls.SuggestionUtility
*/
sap.collaboration.components.controls.SuggestionUtility.convertTextWithFullNamesToEmailAliases = function(sValue, aAtMentionBuffer){
	var sTextWithAlias = "";
	var aBufferLength = aAtMentionBuffer.length;
	var iStartIndex = 0;
	
	if(aBufferLength !== 0){
		for(var i=0; i<aBufferLength; i++){
			if(aAtMentionBuffer[i].atMentioned){ // if the '@mention' in the buffer is a real one
				var sEmailAlias = "@" + aAtMentionBuffer[i].email.split("@")[0];
				sTextWithAlias = sTextWithAlias + sValue.substring(iStartIndex, aAtMentionBuffer[i].startIndex) + sEmailAlias;
			}
			else {
				sTextWithAlias = sTextWithAlias + sValue.substring(iStartIndex, aAtMentionBuffer[i].endIndex + 1);
			}
			iStartIndex = aAtMentionBuffer[i].endIndex + 1;
		}
		// append the remaining text to sTextWithAlias
		sTextWithAlias = sTextWithAlias + sValue.substring(aAtMentionBuffer[aBufferLength - 1].endIndex + 1, sValue.length);
		return sTextWithAlias;
	}
		return sValue;
};

/**
* Function to get the string after the char(s) inserted in an AtMention
* example: '@pter', then the user inserted 'e' after the 'p' now it will be 'peter' and the after string 'ter'
* @public
* @param {integer} iIndexChangedChar
* @param {string} sTextAreaCurrentValue
* @param {object} oAtMentioned - an object containing information about the AtMention
* @returns {string} sStringAfter
* @memberOf sap.collaboration.components.controls.SuggestionUtility
*/

sap.collaboration.components.controls.SuggestionUtility.getStringAfterAtMention = function(iIndexChangedChar, sTextAreaCurrentValue, oAtMentioned){
	var sStringAfter = "";
	var index = iIndexChangedChar;
	
	function buildString() {
		while(sTextAreaCurrentValue[index+1] !== " " && sTextAreaCurrentValue[index+1] !== undefined && sTextAreaCurrentValue[index+1] !== '\n'){
			sStringAfter = sStringAfter.concat(sTextAreaCurrentValue[index+1]);
			index += 1;
		}
	}
	
	buildString();
	
	// the following is to handle a  special case: the char(s) added are part of a @mention that was selected from the suggestions list 
	// and the char(s) added were somewhere in the First Name - in this case we need to skip a space between the First and Last Name and continue
	// to build the string
	if(oAtMentioned.atMentioned && sTextAreaCurrentValue[index+1] === " " && sTextAreaCurrentValue[index+1] <= oAtMentioned.endIndex){
		sStringAfter = sStringAfter.concat(sTextAreaCurrentValue[index+1]);
		index += 1;
		buildString();
	}
	return sStringAfter;
};

/**
* Returns the string before the AtMention 
* @public
* @param {object} oAtMention - an object containing information about the AtMention
* @param {string} sTextAreaCurrentValue - the current value of the text area
* @param {integer} iTextAreaChangeIndex - the index in the text area where the change occured
* @returns {string} sStringBefore - the string before the at AtMention
* @returns {string} sStringBefore
* @memberOf sap.collaboration.components.controls.SuggestionUtility
*/
sap.collaboration.components.controls.SuggestionUtility.getStringBeforeAtMention = function(oAtMention, sTextAreaCurrentValue, iTextAreaChangeIndex){
	var sStringBefore = sTextAreaCurrentValue.substring(oAtMention.startIndex + 1, iTextAreaChangeIndex);

	return sStringBefore;
};
/**
* Converts a text that contains full names to email aliases
* @public
* @param {array} aAtMentionBuffer - the AtMention buffer
* @param {integer} iTextAreaChangeIndex - the index in the text area where the change occurred
* @param {string} sTextAreaChangeChars - the char(s) changed in the text area
* @returns {string} iAtMentionBufferIndex
* @memberOf sap.collaboration.components.controls.SuggestionUtility
*/
sap.collaboration.components.controls.SuggestionUtility.addToAtMentionBuffer = function(aAtMentionBuffer, iTextAreaChangeIndex, sTextAreaChangeChars){
	var iAtMentionBufferIndex;
	var iAtBufferLength = aAtMentionBuffer.length;
	// case #1: the @mention buffer is empty - push the @mention to the buffer
	if(aAtMentionBuffer.length === 0){
		aAtMentionBuffer.push({startIndex: iTextAreaChangeIndex, endIndex: iTextAreaChangeIndex + sTextAreaChangeChars.length - 1, atMentioned: false});
		iAtMentionBufferIndex = 0;
	}
	
	// case #2: the @mention buffer is not empty - update indices for all @mentions in the buffer and insert the new @mention in the correct position
	else {
		// maintain the start and end index for each @mention in the buffer
		for(var i=0; i<iAtBufferLength; i++){
			if(iTextAreaChangeIndex <= aAtMentionBuffer[i].startIndex){
				this.maintainAtMentionIndices(aAtMentionBuffer[i], sTextAreaChangeChars.length);
			}
		}
		// Add the @mention at the right position in the buffer
		for(var i=iAtBufferLength - 1; i>=0; i--){
			if(iTextAreaChangeIndex > aAtMentionBuffer[i].startIndex){
				aAtMentionBuffer.splice(i+1,0,{startIndex: iTextAreaChangeIndex, endIndex: iTextAreaChangeIndex + sTextAreaChangeChars.length - 1 , atMentioned: false});
				iAtMentionBufferIndex = i+1;
				break;
			}
			else if(i === 0){
				aAtMentionBuffer.splice(0,0,{startIndex: iTextAreaChangeIndex, endIndex: iTextAreaChangeIndex + sTextAreaChangeChars.length - 1, atMentioned: false});
				iAtMentionBufferIndex = 0;
			}
		}
	}
	return iAtMentionBufferIndex;
};

/**
* Check if the deleted char(s) was part of an AtMention (from the start to end index) in the buffer
* @public
* @param {array} aAtMentionBuffer - the AtMention buffer
* @param {integer} iTextAreaChangeIndex - the index in the text area where the change occurred
* @returns {object} - an object containing the status and possibly the index
* @memberOf sap.collaboration.components.controls.SuggestionUtility
*/
sap.collaboration.components.controls.SuggestionUtility.isDeletedCharPartOfAtMentioned = function(aAtMentionBuffer, iTextAreaChangeIndex){
	for(var i=0; i<aAtMentionBuffer.length; i++){
		if (iTextAreaChangeIndex >= aAtMentionBuffer[i].startIndex && iTextAreaChangeIndex <= aAtMentionBuffer[i].endIndex){
			return {status : true, index : i};
		}
	}
	return {status : false};
};

/**
* Maintain buffer and return new text area value after selection from '@mentions' list
* @param {string} sFullname - the selected user's Full Name
* @param {string} sEmail - the selected user's Email address
* @param {object} oCurrentAtMention - the current AtMention
* @param {array} aAtMentionBuffer - the AtMention buffer
* @param {string} sTextAreaCurrentValue - the current text area value
* @param {boolean} bNotifyAllSelected - whether the "@@notify" was selected
* @return {string} sNewTextAreaValue - the new text area value
* @public
* @memberOf sap.collaboration.components.controls.SuggestionUtility
*/
sap.collaboration.components.controls.SuggestionUtility.afterSuggestionSelected = function(sFullname, sEmail, oCurrentAtMention, aAtMentionBuffer, sTextAreaCurrentValue, bNotifyAllSelected){
	var startIndex = oCurrentAtMention.startIndex;
	var endIndex = oCurrentAtMention.endIndex;
	var iStringLengthBeforeMentioning = sTextAreaCurrentValue.length;
	var sNewTextAreaValue;
	var sAtNotifyText = this.getLangBundle().getText("ST_ATATNOTIFY").slice(1); // the returned text from the language bundle is "@@notify", we slice the first "@"
	
	if(bNotifyAllSelected){
		sNewTextAreaValue = sTextAreaCurrentValue.substr(0, startIndex + 1) + sAtNotifyText + " " + sTextAreaCurrentValue.substr(endIndex + 1);
		oCurrentAtMention.endIndex = startIndex + sAtNotifyText.length;
		oCurrentAtMention.notifyAll = true;
	}
	else {
		sNewTextAreaValue = sTextAreaCurrentValue.substr(0, startIndex + 1) + sFullname + " " + sTextAreaCurrentValue.substr(endIndex + 1);
		oCurrentAtMention.endIndex = startIndex + sFullname.length;
		oCurrentAtMention.atMentioned = true;
		oCurrentAtMention.email = sEmail;
	}
	
	var iStringLengthAfterMentioning = sNewTextAreaValue.length;
	var iDifferenceInCharacters = iStringLengthAfterMentioning - iStringLengthBeforeMentioning;
	var iIndexOfCurrentAtMention = aAtMentionBuffer.indexOf(oCurrentAtMention);
	for(var i = iIndexOfCurrentAtMention + 1; i < aAtMentionBuffer.length; i++){
		this.maintainAtMentionIndices(aAtMentionBuffer[i], iDifferenceInCharacters);
	}
	
	return sNewTextAreaValue;
};

/**
* Returns a text area value and cursor position after the '@mentions' button has been pressed
* @param {string} sTextAreaValue - the current text area value
* @param {integer} iCursorPosition - current cursor position in text area
* @returns {array} - an array containing the new text area and the cursor position
* @public
* @memberOf sap.collaboration.components.controls.SuggestionUtility
*/
sap.collaboration.components.controls.SuggestionUtility.atMentionsButtonPressed = function(sTextAreaValue, iCursorPosition){
	var iCursorPositionToBeSet;
	var sTextBeforeCursorPosition = sTextAreaValue.slice(0, iCursorPosition);
	var sTextAfterCursorPosition =  sTextAreaValue.slice(iCursorPosition, sTextAreaValue.length);
	var sAtMentionChar = "";
	
	if(sTextAreaValue[iCursorPosition - 1] === " " 
		|| sTextAreaValue[iCursorPosition - 1] === "\n" 
		|| sTextAreaValue[iCursorPosition - 1] === undefined){
		sAtMentionChar = "@";
		iCursorPositionToBeSet = iCursorPosition + 1;
	}
	else {
		sAtMentionChar = " @";
		iCursorPositionToBeSet = iCursorPosition + 2;
	}
	
	var sNewTextAreaValue = sTextBeforeCursorPosition + sAtMentionChar + sTextAfterCursorPosition;
	
	return [sNewTextAreaValue, iCursorPositionToBeSet];
};