/*
* ! @copyright@
*/
sap.ui.define(['jquery.sap.global', 'sap/ui/core/Control', 'sap/collaboration/components/utils/LanguageBundle', 'sap/collaboration/components/controls/PlaceholderUtility', 'sap/collaboration/components/utils/MediaTypeToSAPIcon'],
	function(jQuery, Control, LanguageBundle, placeholderUtility, MediaTypeToSAPIcon) {
	"use strict";
	
	/**
	 * Constructor for a new Feed Entry Embedded Control. 
	 *
	 * @param {string} [sId] id for the new control, generated automatically if no id is given
	 * @param {object} [mSettings] initial settings for the new control
	 *
	 * @class
	 * 
	 * @extends sap.ui.core.Control
	 * The Feed Entry Embedded Control is to be used in a sap.suite.ui.commons.TimelineItem.
	 * @author SAP SE
	 * @version ${version}
	 *
	 * @constructor
	 * @alias sap.collaboration.components.controls.FeedEntryEmbedded
	 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
	 */
	
	var FeedEntryEmbedded = Control.extend("sap.collaboration.components.controls.FeedEntryEmbedded", /** @lends sap.collaboration.components.controls.FeedEntryEmbedded.prototype */ { metadata : {
		interfaces : [],
  		library : "sap.m",
  		properties : {
  			"feedEntry":{type:"object", group:"data"}
  		},
		events : {
			linkPress : {
				parameters : {
					link: {type : "object"},
					feedid : {type : "string"},
					fullname : {type : "string"},
					placeholder : {type : "string"}
				}
			}
		},
		aggregations:{	
		}
	}});
	
	/**
	*  Initializes the Control instance after creation. [borrowed from sap.ui.core.Control]
	* @protected
	* @memberOf sap.collaboration.components.controls.FeedEntryEmbedded
	*/
	FeedEntryEmbedded.prototype.init = function(){
		this._oLangBundle = new LanguageBundle();

		this._aTimelineItemTextDisplay;	// controls (sap.m.Text & sap.m.Link) for the Text
		this._oTimelineItemContent; 		// control for the Content (sap.m.VBox)
		jQuery.sap.includeStyleSheet(jQuery.sap.getModulePath("sap.collaboration.components.resources.css.EmbeddedControl", ".css"));
	};

	/**
	* Function is called before the rendering of the control is started. [borrowed from sap.ui.core.Control]
	* @protected
	* @memberOf sap.collaboration.components.controls.FeedEntryEmbedded
	*/
	FeedEntryEmbedded.prototype.onBeforeRendering = function(){
		if(!this._oTimelineItemContent && !this._aTimelineItemTextDisplay){
			this._createTimelineItemText();
			this._createTimelineItemContent();
		}
	};

	/**
	* Cleans up the control instance before destruction. [borrowed from sap.ui.core.Control]
	* @protected
	* @memberOf sap.collaboration.components.controls.FeedEntryEmbedded
	*/
	FeedEntryEmbedded.prototype.exit = function(){
		if( this._aTimelineItemTextDisplay ){
			this._aTimelineItemTextDisplay.forEach(function(oControl){
				oControl.destroy();
			});
		}
		if( this._oTimelineItemContent ){
			this._oTimelineItemContent.destroy();
		}
	};
	
	/**
	 * Returns the content control
	 * @private
	 * @returns {object} SAPUI5 control
	 * @memberOf sap.collaboration.components.controls.FeedEntryEmbedded
	 */
	FeedEntryEmbedded.prototype._getTimelineItemTextControls = function(){
		return this._aTimelineItemTextDisplay;
	};

	/**
	 * Returns the content control
	 * @private
	 * @returns {object} SAPUI5 control
	 * @memberOf sap.collaboration.components.controls.FeedEntryEmbedded
	 */
	FeedEntryEmbedded.prototype._getTimelineItemContent = function(){
		return this._oTimelineItemContent;
	};
	/**
	 * Creates the controls for the Text
	 * @private
	 * @memberOf sap.collaboration.components.controls.FeedEntryEmbedded
	 */
	FeedEntryEmbedded.prototype._createTimelineItemText = function(){
		var that = this;
		// get the data
		var oFeedEntryData = this.getFeedEntry();
		
		// Regex patter for placeholder
		var placeholderPattern = /@@.\{\d+\}/;
		var oPlaceholderRegex = new RegExp(placeholderPattern);
		
		this._aTimelineItemLinkControls = [];
		this._aTimelineItemTextDisplay = [];

		if(!jQuery.isEmptyObject(oFeedEntryData)) {
		// If the feed entry has placeholders 
			if(oPlaceholderRegex.test(oFeedEntryData.TextWithPlaceholders)) {
				
				var aPlaceholderValues = placeholderUtility.getAtMentionsValues(oFeedEntryData.Text, oFeedEntryData.TextWithPlaceholders);
				var aSplitTextByNewline = oFeedEntryData.TextWithPlaceholders.split("\n");
				
				for(var j=0; j<aSplitTextByNewline.length; j++){
					
					// for each new line, create a line break
					if( j>0){
						this._aTimelineItemTextDisplay.push(new sap.ui.core.HTML({content:"<br/>"}));
					}
					
					var aSplitTextByPlaceholders = placeholderUtility.splitByPlaceholders(aSplitTextByNewline[j]);
					
					for(var i=0; i<aSplitTextByPlaceholders.length; i++){
						
						// if placeholder, create link control
						if(oPlaceholderRegex.test(aSplitTextByPlaceholders[i])){
							
							// TODO: refactor this to a method _createAtMentionLink
							var oLinkControl = {};
							var link = undefined;
							var feedid = oFeedEntryData.Id;
							var placeholderIndex = aSplitTextByPlaceholders[i].replace(/[@a-z{}]/g,"");
							var fullname = aPlaceholderValues[placeholderIndex].value.slice(1);
							var oLink = new sap.m.Link({text: aPlaceholderValues[placeholderIndex].value, tooltip: fullname}).addStyleClass("alignMiddle");
							
							oLinkControl.link = oLink;
							oLinkControl.linkid = oLink.getId();
							oLinkControl.feedid = oFeedEntryData.Id;
							oLinkControl.fullname = fullname;
							oLinkControl.index = placeholderIndex;				
											
							this._aTimelineItemLinkControls.push(oLinkControl);
	
							oLink.attachPress(function(oEvent){
	
								that._aTimelineItemLinkControls.forEach(function(oTimelineItemLinkControl){
									
									var linkid = oEvent.getParameter("id");
	
									if(oTimelineItemLinkControl.linkid == linkid){
										link = oTimelineItemLinkControl.link;
										feedid = oTimelineItemLinkControl.feedid;
										fullname = oTimelineItemLinkControl.fullname;
										placeholderIndex = oTimelineItemLinkControl.index;
									}
								});
	
								that.fireLinkPress({
									link: link,
									feedid: feedid,
									fullname: fullname,
									placeholder: placeholderIndex
								});
							});
	
							this._aTimelineItemTextDisplay.push(oLink);
						}
						// else create a Text control
						else{
							this._aTimelineItemTextDisplay.push(new sap.m.Text({text: aSplitTextByPlaceholders[i]}).addStyleClass("alignMiddle"));		
						}
					}
				}
				
				
			}
			// If feed entry only has normal text
			else {
				
				// do not create text control for the following cases:
				// - feed text is empty
				// - feed entry is consolidated 
				// - feed entry is a Poll
				// - feed entry is a Question
				// - feed entry is an Idea
				// - feed entry is an Event
				// - feed entry is a Task
				// - feed entry is a Blog
				if ( oFeedEntryData.Text == undefined ||
					 oFeedEntryData.Text == "" ||
					 oFeedEntryData.ConsolidatedCount > 1 ||	
					((!jQuery.isEmptyObject(oFeedEntryData.TargetObjectReference)) &&
						(oFeedEntryData.TargetObjectReference.Type == "Task" ||
						oFeedEntryData.TargetObjectReference.Type == "ForumItem" ||
						oFeedEntryData.TargetObjectReference.Type == "Event" ||
						oFeedEntryData.TargetObjectReference.FullPath == "ContentItem/BlogEntry" ||
						oFeedEntryData.TargetObjectReference.FullPath == "ContentItem/Page" ||
						oFeedEntryData.TargetObjectReference.FullPath == "ContentItem/Poll")
					)
				) {
					return;
				}
				// 
				
				this._aTimelineItemTextDisplay.push( new sap.m.Text({text: oFeedEntryData.Text}).addStyleClass("alignMiddle") );
			}
		}
	};
	/**
	 * Called by the renderer. This will render the Text part of the embedded control.
	 * @param oRenderManager
	 * @memberOf sap.collaboration.components.controls.FeedEntryEmbedded
	 */
	FeedEntryEmbedded.prototype._renderTimelineItemText = function(oRenderManager){
		var space = "&nbsp;";
		
	    if(this._aTimelineItemTextDisplay.length > 0){
			oRenderManager.write("<div"); 
		    oRenderManager.writeControlData(this);
		    oRenderManager.write(">");
		
		    for (var i = 0; i < this._aTimelineItemTextDisplay.length; i++) { 

		    	var sClassName = this._aTimelineItemTextDisplay[i].getMetadata().getName();
		    	
		    	switch (sClassName){
		    	case "sap.m.Text":
			    	// WORKAROUND: the SAPUI5 framework trims text automatically when rendering;
			    	// therefore we must add the spaces at the beginning and at the end
			    	var sText = this._aTimelineItemTextDisplay[i].getText();

			    	// adding spaces at the beginning
			    	if(sText.search(/\s/) == 0){
			    		var iFirstNonSpace = sText.search(/\S/);
			    		do {
			    			oRenderManager.write(space);
			    			iFirstNonSpace--;
			    		}
			    		while(iFirstNonSpace > 0);
			    	}
			    	oRenderManager.renderControl(this._aTimelineItemTextDisplay[i]);
			    	
			    	// adding spaces at the end
			    	if( sText[sText.length-1] == " " ){
			    		var index = sText.length-1;
			    		var character = sText[index];
			    		do{
			    			oRenderManager.write(space);
			    			character = sText[--index];
			    		}
			    		while(character == " " && character != undefined);
			    	}
			    	
		    		break;
		    	case "sap.m.Link":
		    	case "sap.ui.core.HTML":
		    	default:
		    		oRenderManager.renderControl(this._aTimelineItemTextDisplay[i]);
		    	}
		    }
		    oRenderManager.write("</div>");
	    }
	};

	/**
	 * Create the control for the Content 
	 * @private
	 * @memberOf sap.collaboration.components.controls.FeedEntryEmbedded
	 */
	FeedEntryEmbedded.prototype._createTimelineItemContent = function(){
		
		this._oTimelineItemContent = new sap.m.VBox({});
		
		// get the data
		var oFeedEntryData =  this.getFeedEntry();
		
		// feed entry content
		if( (!jQuery.isEmptyObject(oFeedEntryData.TargetObjectReference) 
				&& oFeedEntryData.TargetObjectReference.Type !== undefined 
				&& oFeedEntryData.TargetObjectReference.Type !== "FeedEntry") ||
			oFeedEntryData.ConsolidatedCount > 1 ){
			
			this._oTimelineItemContent.addItem(this._createFeedEntryContent(oFeedEntryData));
		}
	};

	/**
	 * Create the control for a feed entry with a target object reference. 
	 * @param oFeedEntryData
	 * @returns {sap.m.HBox} 
	 * @memberOf sap.collaboration.components.controls.FeedEntryEmbedded
	 */
	FeedEntryEmbedded.prototype._createFeedEntryContent = function(oFeedEntryData){
		
		var sIconSrc = "";
		var sLinkText = "";
		var sLinkHref = "";
		
		if( oFeedEntryData.ConsolidatedCount > 1 ) {
			sIconSrc = "sap-icon://documents";
			sLinkText = this._oLangBundle.getText("TE_CONSOLIDATED_FEED_TEXT");
			sLinkHref = oFeedEntryData.WebURL;
		}
		else {
			switch (oFeedEntryData.TargetObjectReference.Type){
			case "ContentItem":
				if(oFeedEntryData.TargetObjectReference.ContentType){
					sIconSrc = MediaTypeToSAPIcon.getSAPIconForMediaType(oFeedEntryData.TargetObjectReference.ContentType);
					sLinkText = placeholderUtility.getContentItemName(oFeedEntryData.Action, oFeedEntryData.ActionWithPlaceholders);	
				}
				else{
					switch (oFeedEntryData.TargetObjectReference.FullPath){	
					case "ContentItem/Poll":
						sIconSrc = "sap-icon://horizontal-bar-chart";
						break;
					case "ContentItem/Page":
						sIconSrc = "sap-icon://e-learning";
						break;
					case "ContentItem/BlogEntry":
						sIconSrc = "sap-icon://request";
						break;
					default:
						sIconSrc = "";
						break;
					}
					sLinkText = oFeedEntryData.TargetObjectReference.Title;
				}
				break;
			case "ForumItem":
				sIconSrc = this._getForumItemIconSrc(oFeedEntryData.TargetObjectReference);
				sLinkText = oFeedEntryData.TargetObjectReference.Title;
				break;
			case "Task":
				sIconSrc = "sap-icon://task";
				sLinkText = oFeedEntryData.TargetObjectReference.Title;
				break;
			case "Event":
				sIconSrc = "sap-icon://calendar";
				sLinkText = oFeedEntryData.TargetObjectReference.Title;
				break;
			default:
				sIconSrc = "sap-icon://action";
				sLinkText = oFeedEntryData.TargetObjectReference.Title;
				break;
			}
			sLinkHref = oFeedEntryData.TargetObjectReference.WebURL;
		}
		// icon
		var ICON_SIZE = "2.5em";
		var oIcon = new sap.ui.core.Icon( {src: sIconSrc, size: ICON_SIZE} ).addStyleClass("sapUiTinyMarginBegin");
		// link
		var oLink = new sap.m.Link( {text: sLinkText, target: "_blank",	href: sLinkHref, tooltip: sLinkText	});
		
		var oHBox = new sap.m.HBox({});
		oHBox.addItem(oIcon);
		var oVBox = new sap.m.VBox({}).addStyleClass("sapUiTinyMarginBegin"); // Vbox in case we want to add text under the link
		oVBox.addItem(oLink);
		oHBox.addItem(oVBox);
		
		return oHBox;
	};
	
	/**
	 * Get the icon source for a Forum Item.  
	 * @param oForumItem
	 * @returns {String}
	 */
	FeedEntryEmbedded.prototype._getForumItemIconSrc = function(oForumItem){
		
		var sFullPath = oForumItem.FullPath;
		
		switch (sFullPath){
		case "ForumItem/Inquiry":
		case "ForumItem/Question":
			return "sap-icon://question-mark";
		case "ForumItem/Idea":
			return "sap-icon://lightbulb";
		case "ForumItem/Discussion":
			return "sap-icon://discussion";
		default:
			return "";
		}
	};
	
	return FeedEntryEmbedded;
}, /* bExport= */ true);