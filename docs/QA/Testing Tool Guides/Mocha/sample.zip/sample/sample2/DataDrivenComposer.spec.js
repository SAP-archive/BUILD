	//Define components under testing
	var dataDrivenComposer = require('./DataDrivenComposer');
	//Define assertion Library
	var should = require('chai').should();
	var expect = require('chai').expect;

	//Initialize context variable
	var context = {
		propertySet: [
			{propertyName: 'toto0'}
		],
		pageTemplate: 'masterList'
	};

	//TestSuite
	describe('Test DataComposer 1', function () {
		//Call tested function
		var control = dataDrivenComposer.getSuggestion(context);
		//TestCase 1
		it('should be an Array', function () {
			control.should.be.instanceof(Array);
		});
		//TestCase 2
		it('expect controlName : sap.m.StandardListItem', function () {
			expect(control[0].controlName).equal('sap.m.StandardListItem');
		});
		//TestCase 3
		it('expect lib: ui5', function () {
			expect(control[0].uiCatalogName).equal('ui5')
		});
	})

	//TestSuite
	describe('Test DataComposer 2', function () {
		//Modify context before test
		propName = {propertyName: 'toto' + context.propertySet.length};
		context.propertySet.push(propName);
		//Call tested function
		var control = dataDrivenComposer.getSuggestion(context);
		//TestCase 1
		it('should be an Array', function () {
			control.should.be.instanceof(Array);
		});
		//TestCase 2
			it('expect controlName : sap.m.StandardListItem', function () {
			expect(control[0].controlName).equal('sap.m.StandardListItem');
		});
		//TestCase 3
		it('expect lib: ui5', function () {
			expect(control[0].uiCatalogName).equal('ui5')
		});
	})

	//TestSuite
	describe('Test DataComposer 3', function () {
		//Modify context before test
		propName = {propertyName: 'toto' + context.propertySet.length};
		context.propertySet.push(propName);
		//Call tested function
		var control = dataDrivenComposer.getSuggestion(context);
		//TestCase 1
		it('should be an Array', function () {
			control.should.be.instanceof(Array);
		});
		//TestCase 2
		it('expect controlName : sap.m.ObjectHeader', function () {
			expect(control[0].controlName).equal('sap.m.ObjectHeader');
		});
		//TestCase 3
		it('expect lib: ui5', function () {
			expect(control[0].uiCatalogName).equal('ui5')
		});
	})

	//TestSuite
	describe('Test DataComposer 4', function () {
		//Modify context before test
		propName = {propertyName: 'toto' + context.propertySet.length};
		context.propertySet.push(propName);
		//Call tested function
		var control = dataDrivenComposer.getSuggestion(context);
		//TestCase 1
		it('should be an Array', function () {
			control.should.be.instanceof(Array);
		});
		//TestCase 2
		it('expect controlName : sap.m.IconTabBar', function () {
			expect(control[0].controlName).equal('sap.m.IconTabBar');
		});
		//TestCase 3
		it('expect lib: ui5', function () {
			expect(control[0].uiCatalogName).equal('ui5')
		});
	})
	
	//TestSuite
	describe('Test DataComposer 5', function () {
		//Modify context before test
		propName = {propertyName: 'toto' + context.propertySet.length};
		context.propertySet.push(propName);
		//Call tested function
		var control = dataDrivenComposer.getSuggestion(context);
		//TestCase 1
		it('should be an Array', function () {
			control.should.be.instanceof(Array);
		});
		//TestCase 2
		it('expect controlName : sap.m.Label', function () {
			expect(control[0].controlName).equal('sap.m.Label');
		});
		//TestCase 3
		it('expect lib: ui5', function () {
			expect(control[0].uiCatalogName).equal('ui5')
		});
	})