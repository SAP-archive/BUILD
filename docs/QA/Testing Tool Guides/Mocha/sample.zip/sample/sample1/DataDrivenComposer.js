	exports.getSuggestion = function (context) {
		var controls = [];
		switch (context.propertySet.length) {
			case 1:
				controls.push({
					controlName: "sap.m.StandardListItem",
					uiCatalogName: "ui5",
					binding: [
						{
							entityPath: context.propertySet[0].propertyName,
							controlProperty: "title"
						}
					]
				});
				break;
			case 2:
				controls.push({
					controlName: "sap.m.StandardListItem",
					uiCatalogName: "ui5",
					binding: [
						{
							entityPath: context.propertySet[0].propertyName,
							controlProperty: "title"
						},
						{
							entityPath: context.propertySet[1].propertyName,
							controlProperty: "description"
						}
					]
				});
				break;
			case 3:
				controls.push({
					controlName: "sap.m.ObjectHeader",
					uiCatalogName: "ui5",
					binding: [
						{
							entityPath: context.propertySet[0].propertyName,
							controlProperty: "title"
						},
						{
							entityPath: context.propertySet[1].propertyName,
							controlProperty: "number"
						},
						{
							entityPath: context.propertySet[2].propertyName,
							controlProperty: "numberUnit"
						}
					]
				});
				break;
			case 4:
				controls.push({
					controlName: "sap.m.IconTabBar",
					uiCatalogName: "ui5",
					binding: [
						{
							entityPath: context.propertySet[0].propertyName,
							controlProperty: "text"
						},
						{
							entityPath: context.propertySet[1].propertyName,
							controlProperty: "text"
						},
						{
							entityPath: context.propertySet[2].propertyName,
							controlProperty: "text"
						},
						{
							entityPath: context.propertySet[3].propertyName,
							controlProperty: "text"
						}
					]
				});
				break;
			default:
				controls.push({
					controlName: "sap.m.Label",
					uiCatalogName: "ui5",
					binding: [
						{
							entityPath: context.propertySet[0].propertyName,
							controlProperty: "text"
						}
					]
				});
				break;
		}
		return controls;
	};