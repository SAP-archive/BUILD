//Define components under testing
var dataDrivenComposer = require('./DataDrivenComposer');
//Define assertion Library
var should = require('chai').should();
var expect = require('chai').expect;

//Initialize context variable
var context = {
    propertySet: [
        {propertyName: 'toto0'}
    ],
    pageTemplate: 'masterList'
};

//TestSuite
describe('Test DataComposer', function () {
    //Call tested function
    var control = dataDrivenComposer.getSuggestion(context);
    //TestCase 1
    it('should be an Array', function () {
        control.should.be.instanceof(Array);
    });
    //TestCase 2
    it('expect controlName : sap.m.StandardListItem', function () {
        expect(control[0].controlName).equal('sap.m.StandardListItem');
    });
    //TestCase 3
    it('expect lib: ui5', function () {
        expect(control[0].uiCatalogName).equal('ui5')
    });
})