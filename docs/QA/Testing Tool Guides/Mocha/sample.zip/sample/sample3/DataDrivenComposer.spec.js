	//Define components under testing 
	var dataDrivenComposer = require('./DataDrivenComposer');
	//Define assertion Library
	var should = require('chai').should();
	var expect = require('chai').expect;
	
	//Initialize context variable
	var context = {
		propertySet: [
			{propertyName: 'toto0'}
		],
		pageTemplate: 'masterList'
	};
	
	//Add one propertyName in the propertySet collection of context
	function contextAddPropertyName() {
		propName = {propertyName: 'toto' + context.propertySet.length};
		context.propertySet.push(propName);
	}
	
	//Define expected results
	var expectedValue = ["sap.m.StandardListItem", "sap.m.StandardListItem", "sap.m.ObjectHeader", "sap.m.IconTabBar", "sap.m.Label"];
	
	//Loop for each expected result
	expectedValue.forEach(function(val){
		//TestSuite
		describe('Test DataComposer', function () {
				//Call tested function
				var control = dataDrivenComposer.getSuggestion(context);
				//TestCase 1
				it('should be an Array', function () {
					control.should.be.instanceof(Array);
				});
				//TestCase 2
				it('expect controlName : ' + val, function () {
					expect(control[0].controlName).equal(val);
				});
				//TestCase 3
				it('expect lib: ui5', function () {
					expect(control[0].uiCatalogName).equal('ui5')
				});
				//Modify context before next loop
				contextAddPropertyName();
			}
		)
	});