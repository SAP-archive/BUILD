	//Define components under testing 
	var dataDrivenComposer = require('./DataDrivenComposer');
	//Define assertion Library
	var should = require('chai').should();
	var expect = require('chai').expect;
	
	//Initialize context variable
	var context = require('./context.json');
	
	//Add one propertyName in the propertySet collection of context
	function contextAddPropertyName() {
		propName = {propertyName: 'toto' + context.propertySet.length};
		context.propertySet.push(propName);
	}
	
	//Define expected results
	var expectedValue = require('./expectedResult.json');
	
	//Loop for each expected result
	expectedValue.forEach(function(item){
		//TestSuite
		describe('Test DataComposer', function () {
				//Call tested function
				var control = dataDrivenComposer.getSuggestion(context);
				//TestCase 1
				it('should be an Array', function () {
					control.should.be.instanceof(Array);
				});
				//TestCase 2
				it('expect controlName : ' + item.controlName, function () {
					expect(control[0].controlName).equal(item.controlName);
				});
				//TestCase 3
				it('expect lib: ' + item.lib, function () {
					expect(control[0].uiCatalogName).equal(item.lib)
				});
				//Modify context before next loop
				contextAddPropertyName();
			}
		)
	});