/**
 * Express configuration
 */

'use strict';

var express = require('express');
var bodyParser = require('body-parser');
var config = require('./environment');


module.exports = function(app) {
  var env = app.get('env');

  app.set('views', config.root + '/server/views');
  app.use(bodyParser.json());

};