'use strict';

var mongoose = require('mongoose'),
    Schema = mongoose.Schema;

/**
 * Project Schema
 */
var ProjectSchema = new Schema({
    _tenant_id: String,
    name: String,
    owner: String,
    description: String,
    tag: String
});

module.exports = mongoose.model('Project', ProjectSchema);
