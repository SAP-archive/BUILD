'use strict';

var Project = require('./project.model');

/***************************
 *      Project
 ***************************/

// Get list of projects
exports.index = function (req, res) {
    Project.find(function (err, projects) {
        if (err) {
            return handleInternalServerError(res, err);
        }
        return res.json(200, projects);
    });
};

// Get a single project
exports.show = function (req, res) {
    Project.findById(req.params.projectId, function (err, project) {
        if (err) {
            return handleInternalServerError(res, err);
        }
        if (!project) {
            return res.send(404);
        }
        return res.json(project);
    });
};

// Creates a new project in the DB.
exports.create = function (req, res) {
    // Could use mongoose-q to make this easier
    var oProject = req.body;
    var fnCreate = function (oProject, res, callBack) {
        Project.create(oProject, function (err, project) {
            if (err) {
                return handleInternalServerError(res, err );
            }
            if (callBack && typeof callBack == "function") {
                callBack(project, function (err, project) {
                    if (err) {
                        return handleInternalServerError(res, err);
                    }
                    return res.json(201, project);
                });
            } else {
                return res.json(201, project);
            }
        });
    };
    fnCreate(oProject, res);
};

// Updates an existing project in the DB.
exports.update = function (req, res) {
    if (req.body._id) {
        delete req.body._id;
    }
    Project.findByIdAndUpdate(req.params.projectId, req.body, function (err, project) {
        if (err) {
            return handleInternalServerError(res, err);
        }
        if (!project) {
            return res.send(404);
        }

        return res.json(200, project);
    });
};

// Deletes a project from the DB.
exports.destroy = function (req, res) {
    Project.findById(req.params.projectId, function (err, project) {
        if (err) {
            return handleInternalServerError(res, err);
        }
        if (!project) {
            return res.send(404);
        }
        project.remove(function (err) {
            if (err) {
                return handleInternalServerError(res, err);
            }
            return res.send(204);
        });
    });
};

/************************************
 ********* Error Handlers  **********
 ************************************/

function handleInternalServerError(res, err) {
    console.log(err);
    return res.send(500, err);
}

function handleBadRequest(res, err) {
    console.log(err);
    return res.send(400, err);
}

