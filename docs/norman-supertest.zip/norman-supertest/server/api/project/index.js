'use strict';

var express = require('express');
var controller = require('./project.controller');

var router = express.Router();

/******************************************************************************
 *      Project
 *
 * Using Rails-like standard naming convention for endpoints.
 * GET     /projects                    ->  index
 * POST    /projects                    ->  create
 * GET     /projects/:projectId         ->  show
 * PUT     /projects/:projectId         ->  update
 * DELETE  /projects/:projectId         ->  destroy
 *
 ******************************************************************************/

router.post('/', controller.create);
router.get('/', controller.index);
router.get('/:projectId', controller.show);
router.put('/:projectId', controller.update);
router.delete('/:projectId', controller.destroy);

module.exports = router;