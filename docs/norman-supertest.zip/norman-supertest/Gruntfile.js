// Generated on 2014-11-12 using generator-norman 1.2.0
'use strict';

module.exports = function (grunt) {
    var localConfig;

    // Load grunt tasks automatically, when needed
    require('jit-grunt')(grunt, {
        express: 'grunt-express-server'
    });

    // Define the configuration for all the tasks
    grunt.initConfig({

        // Project settings
        pkg: grunt.file.readJSON('package.json'),
        express: {
            options: {
                port: process.env.PORT || 9000
            },
            test: {
                options: {
                    script: 'server/app.js',
                    debug: false
                }
            }
        },

        // Test settings
        mochaTest: {
            options: {
                reporter: 'spec'
            },
            src: ['test/**/*.spec.js']
        },

        env: {
            dev: {
                NODE_ENV: 'development'
            },
            all: {
                NODE_ENV: 'development'
            }
        }
    });

// Used for delaying livereload until after server has restarted
    grunt.registerTask('test', function (target) {
        if (target === 'serverOn') {
            return grunt.task.run([
                'env:all',
                'env:dev',
                'express:test',
                'mochaTest'
            ]);
        }
        else{
            return grunt.task.run([
                'env:all',
                'env:dev',
                'mochaTest'
            ]);
        }
    });

};