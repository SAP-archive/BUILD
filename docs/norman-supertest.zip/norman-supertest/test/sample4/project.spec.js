'use strict';

var should = require('chai').should();
var expect = require('chai').expect;
var app = require('../../server/app');
var request = require('supertest');

var result;
var postValue1 = require('./testMaterial/postValue1.json');
var postValue2 = require('./testMaterial/postValue2.json');
var postValue3 = require('./testMaterial/postValue3.json');

describe('Valid Test', function () {
    describe('GET All projects', function () {
        it('Call GET /api/projects - should respond 200 with JSON array', function (done) {
            request(app)
                .get('/api/projects')
                .expect(200)
                .expect('Content-Type', /json/)
                .end(function (err, res) {
                    if (err) return done(err);
                    res.body.should.be.instanceof(Array);
                    done();
                });
        });
    });

    describe('Create a new project Magic Name', function () {
        it('Call POST /api/projects - should respond 201 whit Content-Type json', function (done) {
            request(app)
                .post('/api/projects')
                .send(postValue1)
                .expect(201)
                .end(function (err, res) {
                    result = res.body;
                    if (err) return done(err);
                    done();
                });
        });
    });

    describe('Get specific project', function () {
        it('Call GET /api/projects/:id - should respond 200 with name and description equal to postValue', function (done) {
            request(app)
                .get('/api/projects/' + result._id)
                .expect(200)
                .end(function (err, res) {
                    expect(res.body.name).equal(postValue1.name);
                    expect(res.body.description).equal(postValue1.description);
                    if (err) return done(err);
                    done();
                });
        });
    });
    describe('Update specific project /api/projects/:id and update Name', function () {
        it('Call PUT /api/projects/:id - should respond 200 with with name and description equal to postValue2', function (done) {
            request(app)
                .put('/api/projects/' + result._id)
                .send(postValue2)
                .expect(200)
                .end(function (err, res) {
                    expect(res.body.name).equal(postValue2.name);
                    expect(res.body.description).equal(postValue2.description);
                    if (err) return done(err);
                    done();
                });
        });
    });

    describe('Get specific project', function () {
        it('Call GET /api/projects/:id - should respond 200 with name and description equal to postValue2', function (done) {
            request(app)
                .get('/api/projects/' + result._id)
                .expect(200)
                .end(function (err, res) {
                    expect(res.body.name).equal(postValue2.name);
                    expect(res.body.description).equal(postValue2.description);
                    if (err) return done(err);
                    done();
                });
        });
    });

    describe('DELETE /api/projects/:id', function () {
        it('Call GET /api/projects/:id - should respond 204', function (done) {
            request(app)
                .delete('/api/projects/' + result._id)
                .expect(204)
                .end(function (err, res) {
                    if (err) return done(err);
                    done();
                });
        });
    });
});

describe('Invalid Test', function () {
    describe('GET All project with wrong URL', function () {
        it('Call GET /api/project - should respond 404', function (done) {
            request(app)
                .get('/api/project')
                .expect(404, done);
        });
    });
    describe('Get specific project with wrong id', function () {
        it('Call GET /api/projects/:id - should respond 404 with error', function (done) {
            request(app)
                .get('/api/projects/' + result._id)
                .expect(404, done)
        });
        describe('Get specific project with invalid id', function () {
            it('Call GET /api/projects/:id - should respond 500 with error', function (done) {
                request(app)
                    .get('/api/projects/0')
                    .expect(500, done)
            });
        });
        describe('Try a new project with bad value', function () {
            it('Call POST /api/projects with bad value- should respond 500', function (done) {
                request(app)
                    .post('/api/projects')
                    .send(postValue3)
                    .expect(500, done)
            });
        });
    });
});